package practice;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class LinkedListPractice {

	public static void main(String[] args) {
		LinkedList<String> linkedList = new LinkedList<String>(
				Arrays.asList("Nandan1", "Nandan2", "Nandan3", "Nandan3", "Nandan4"));

		linkedList.add(1, "Nandan1v2");
//		System.out.println(linkedList);

//		Iterator<String> iterator = linkedList.descendingIterator();
//		while (iterator.hasNext()) {
////			System.out.println(iterator.next());
//
//		}

//		ListIterator<String> iterator2 = linkedList.listIterator(linkedList.size());
//		while (iterator2.hasPrevious()) {
//			System.out.println(iterator2.previous());
//
//		}
		
		linkedList.addFirst("I am first" );
		linkedList.addLast("I am last");
		System.out.println(linkedList);
		
		System.out.println(linkedList.getFirst());
		System.out.println(linkedList.getLast());
		
		System.out.println(linkedList.peek());
		System.out.println(linkedList.peekFirst());
		System.out.println(linkedList.peekLast());
		linkedList.poll();
		linkedList.pollFirst();
		linkedList.pollLast();		
		linkedList.push("I am new");
		System.out.println(linkedList);

	}

}
