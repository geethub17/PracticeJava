package practice;


public class Operators {

	public static void main(String[] args) {
		Object [] arr = new Object[3];
	    arr[0] = new Object(); 
	     arr[1] = new String("COFORGE"); 
	     arr[2] = new Integer(10); 
	     
	     for(Object a : arr) {
	    	 System.out.println(a);
	     }

	}
}
