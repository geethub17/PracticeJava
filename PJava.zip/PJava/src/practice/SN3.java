package practice;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SN3 {

//	To find largest sum of sub array in a given array with continuous numbers locations 
//	arr = {-2,-3, 4,-1,-2,1,5,-3}
//	O/p = 7  = {4,-1,-2,1,5}

	public static int largestSum(int[] nums) {

		List<Integer> list = new ArrayList<Integer>();
		int sum = 0;

		for (int i = 0; i < nums.length; i++) { // n=8^2 = 64
			for (int j = i; j < nums.length; j++) {// n=64
				if (i == 0) {
					sum += nums[i] + nums[j];
				} else {
					sum += nums[j];
				}
				list.add(sum);
			}
			sum = 0;
		}

		return Collections.max(list);
	}

	public static int largestSum2(int[] nums) {

		List<Integer> list = new ArrayList<Integer>();
		int sum = 0, j = 0;

		for (int i = j; i < nums.length; i++) {
			sum += nums[i];
			list.add(sum);

			if (i == (nums.length - 1) && j < nums.length) {
				i = j++;
				sum = 0;
			}
		}
		return Collections.max(list);
	}

	public static int largestSum3(int[] a) {

		int size = a.length;
		int max_so_far = a[0];
		int max_ending_here = 0;

		for (int i = 0; i < size; i++) {
			max_ending_here = max_ending_here + a[i];
			if (max_so_far < max_ending_here) {
				max_so_far = max_ending_here;
			}
			if (max_ending_here < 0) {
				max_ending_here = 0;
			}
		}
		return max_so_far;
	}

	public static void main(String[] args) {
		System.out.println(SN3.largestSum3(new int[] { -2, -3, 4, -1, -2, 1, 5, -3 }));
	}
}
