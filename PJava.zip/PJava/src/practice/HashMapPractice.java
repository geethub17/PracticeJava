package practice;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class HashMapPractice {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
		hashMap.put("one", 1);
		hashMap.put("Five", 5);
		hashMap.put("two", 2);
		hashMap.put("three", 3);
		hashMap.put("four", 4);
		hashMap.put(null, 0);
		hashMap.put(null, 0);
		hashMap.putIfAbsent("six", 6);

		for (Map.Entry<String, Integer> m : hashMap.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}

		Set<String> keys = hashMap.keySet();
		Collection<Integer> values = hashMap.values();

		System.out.println(keys);
		System.out.println(values);

		for (int i = 0; i < hashMap.size(); i++) {
//			System.out.println(hashMap.);
		}

		Set<Map.Entry<String, Integer>> entries = hashMap.entrySet();
		Iterator<Map.Entry<String, Integer>> iterator = entries.iterator();
		while (iterator.hasNext()) {
			Map.Entry<String, Integer> keyAndValue = iterator.next();
			System.out.println(keyAndValue.getKey() + " & " + keyAndValue.getValue());
		}
		
		hashMap.forEach((k,v) -> {
			System.out.println(k);
			System.out.println(v);
	});

	}
}
