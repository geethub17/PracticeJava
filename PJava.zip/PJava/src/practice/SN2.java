package practice;

public class SN2 {
	int a[] = new int[10];
	int i = 0;

	public void add(int element) {
		if (i < 10) {
			a[i] = element;
			i++;
		} else {
			System.out.println("Array is full.");
		}
	}

	public void pop() {
		if (i > 0) {
			a[--i] = 0;
		}else {
			System.out.println("Array is empty.");
		}
	}

	public void peek() {
		System.out.println(a[0]);
	}

	public static void main(String[] args) {
		SN2 sn2 = new SN2();
		sn2.add(2); //Adds 2 to array
		sn2.add(3);//Adds 3 to array
		sn2.pop(); //Removes 3
		sn2.pop();//Removes 2
		sn2.pop(); //Nothing to remove
		sn2.add(4);//Adds 4 to array
		sn2.peek();//Returns 4
	}

	int arr[] = { 1, 2, 0, 0, 3, 0, 9, 8, 11, 0, 4, 0, 0 };

//	JavaScriptExecutor js = (JavaScriptExecuto) driver;
//	js.executeScript( argument[0].click());
//	
//	
//	//Post
//	Response res = RestAssured()
//	.given()
//	.baseURI("URL")
//	.headers("headers")
//	.body("{}")
//	.post()
//	.assert()
//	.that
//	.responseCode(201);
//	
//	
//	
//	org.json;
//	
//	JSONObject obj  =new JSONObject;
//	
//	//Deployment is in progress
//	//Server load
//	// Low speed interenet
//	//Too much cache and cookies
//	// Broken functionality
//	//Peek time

}
