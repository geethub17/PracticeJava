package practice;

public class NumArray {

	/* https://leetcode.com/problems/range-sum-query-immutable/ */

	 int[] sums;

	  	public NumArray(int[] nums) {
			sums = new int[nums.length + 1];
			for (int i = 0; i < nums.length; i++) {
				sums[i + 1] = sums[i] + nums[i];
			}
		}

		public int sumRange(int i, int j) {
			return sums[j + 1] - sums[i];
		}

	public static void main(String[] args) {
		int[] nums = { -2, 0, 3, -5, 2, -1 };
		int i = 0;
		int j = 2;
		NumArray obj = new NumArray(nums);
		int param_1 = obj.sumRange(i, j);
		System.out.println(param_1);

	}

}
