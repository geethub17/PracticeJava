package practice;

import java.util.ArrayList;
import java.util.List;

interface Drawable {
	void draw();
}

public class LambdaExpressions {
	public static void main(String[] args) {
		Drawable drawable = () -> System.out.println("Drawing..");
//		drawable.draw();
		

		//foreach
		List<String> list=new ArrayList<String>();  
        list.add("ankit");  
        list.add("mayank");  
        list.add("irfan");  
        list.add("jai");  
          
        list.forEach(  
            (n)->System.out.println(n.equals("ankit"))  
         );  
	}
}
