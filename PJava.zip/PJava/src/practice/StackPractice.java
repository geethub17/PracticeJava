package practice;

import java.util.Arrays;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Stack;

public class StackPractice {
	public static void main(String[] args) {
		Stack<String> stack = new Stack<String>();
		stack.add("Nandan");
		stack.add("Nandan1");
		stack.add("Nandan4");
		stack.add("Nandan4");
		stack.add("Nandan3");
		stack.add("Nandan4");
		stack.add("Nandan5");
		stack.push("NandanFirst");
		System.out.print(stack);

		Enumeration<String> enumeration = stack.elements();
		while (enumeration.hasMoreElements()) {
			System.out.println(enumeration.nextElement());
		}
		Iterator<String> iterator = stack.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		ListIterator<String> list1 = stack.listIterator(stack.size());
		while (list1.hasPrevious()) {
			System.out.println(list1.previous());
		}
		System.out.println("*********");
		System.out.println(stack.peek());

	}
}
