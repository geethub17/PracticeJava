package practice;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CollecetionsClassPractice {

	public static void main(String[] args) {

//		// addAll
//		ArrayList<String> arrayList = new ArrayList<String>();
//		arrayList.add("Nandan1");
//		arrayList.add("Nandan2");
//		arrayList.add("Nandan4");
//		arrayList.add("Nandan3");
//		arrayList.add("Nandan5");
//		Collections.addAll(arrayList, "Nadnan6, Nandan7");
////		System.out.println(arrayList);
//
//		// asLifoQueue()
//		Deque<String> dque = new ArrayDeque<String>();
//		dque.add("Java");
//		dque.add("C");
//		dque.add("C++");
//		dque.add("Unix");
//		dque.add("Perl");
//		Queue<String> q = Collections.asLifoQueue(dque);
////         System.out.println(q);  
//		q.add("I am new");
////         System.out.println(q);  
//
//		// binarysearch
////         Collections.sort(arrayList);
////         System.out.println(Collections.binarySearch(arrayList, "Nandan3"));
//
//		ArrayList<Integer> arrlist = new ArrayList<Integer>();
//		arrlist.add(10);
//		arrlist.add(-20);
//		arrlist.add(30);
//		arrlist.add(-40);
//		arrlist.add(50);
//		// Print List
////         System.out.println("Provided List are: "+arrlist);  
//		// Search the list for key '-20'
//		int index = Collections.binarySearch(arrlist, -20);
////         System.out.println("Index '-20' is available at position: "+index);  
//
//		// copy
//		List<Integer> source = Arrays.asList(1, 2, 3, 4);
//		List<Integer> dest = Arrays.asList(5, 6, 7, 8, 9);
//		Collections.copy(dest, source);
////         System.out.println(dest);
//
//		// disjoint
//		ArrayList<String> arrayList1 = new ArrayList<String>(Arrays.asList("Nandan", "Nandan2", "Nandan3"));
//		ArrayList<String> arrayList2 = new ArrayList<String>(Arrays.asList("Nandan4", "Nandan5", "Nandan6"));
////		System.out.println(Collections.disjoint(arrayList1, arrayList2));
//
//		// max
//		List<Integer> list = Arrays.asList(201, 101, 1001, 30000, 140, 2501);
////		System.out.println("Output: " + Collections.max(list));
////		System.out.println("Output: " + Collections.max(list, Collections.reverseOrder()));
//
//		// revrese
//		Collections.reverse(list);
////		System.out.println(list);
//
//		// reverseOrder
//		List<Integer> list3 = Arrays.asList(201, 101, 1001, 30000, 140, 2501);
//		Collections.sort(list3, Collections.reverseOrder());
////		System.out.println(list3);
//		
//		//rotate
//		List<Integer> list4 = Arrays.asList(201, 101, 1001, 30000, 140, 2501);
//		Collections.rotate(list4, 2);
////		System.out.println(list4);
//		
//		
//		//singleton
//		List<Integer> list5 = Arrays.asList(1,2,2,3,4,2,5,6,7,8,9);
//		list5.removeAll(Collections.singleton(2));
//		System.out.println(list5);
//		Set<Integer> list5 = Collections.singleton(1);
//		list5.add(3);//throws UnsupportedOperationException

		//singletonlist
//		List<Integer> list5 = Collections.singletonList(2);
//		list5.add(5);//throws UnsupportedOperationException
//		list5.remove(1); //UnsupportedOperationException
//		System.out.println(list5.get(0));

		// singletonmap
//		Map<Integer, String> m1 = Collections.singletonMap(1, "Monday");
//		m1.put(2, "New"); // Throws UnsupportedOperationException
		
		List<Integer> list5 = Arrays.asList(1,2,2,10,3,4,2,5,6,7,8,9);
		Collections.swap(list5, 0, list5.size()-1);
		System.out.println(list5);

	}
}
