package practice;

public class MathClass {

	public static void main(String[] args) {
		System.out.println(Math.max(10, 9));
		System.out.println(Math.pow(2, 3));
		System.out.println(Math.abs(0.5959));

	}

}
