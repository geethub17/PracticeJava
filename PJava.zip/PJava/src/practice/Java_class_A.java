package practice;

import java.io.CharArrayReader;
import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Java_class_A {

	public static int sum(int value) {

		if (value > 0) {

			return value + sum(value - 1);

		} else {

			return 0;

		}

	}

	public void methodOfClass() {
		System.out.println("Method of class A");
	}

	public void finalize() {
		System.out.println("object is garbage collected");
	}

	private String myName = "Nandan";

	public String getMyName() {
		return myName;
	}

	public void setMyName(String myName) {
		this.myName = myName;
	}

	static int fuitValue = 0;

	public boolean isFileAvailable(String downloadPath, String fileName) {

		int waitTillSeconds = 30;
		long passedTimeInSeconds = 0;
		boolean fileDownloaded = false;

		long waitTillTime = Instant.now().getEpochSecond() + waitTillSeconds;
		while (passedTimeInSeconds < waitTillTime) {
			passedTimeInSeconds = Instant.now().getEpochSecond();

			File dir = new File(downloadPath);
			File[] dirContents = dir.listFiles();

			for (int i = 0; i < dirContents.length; i++) {
				if (dirContents[i].getName().equals(fileName)) {
					System.out.println("File downloaded.");
					fileDownloaded = true;
					break;
				}
			}
			if (fileDownloaded) {
				break;
			}
		}
		return fileDownloaded;
	}

	public static void fibonicSeries(int tillNumber) {
		int a = 0;
		int b = 1;
		int temp1 = 0;
		int temp2 = 0;
		int temp3 = 0;

		temp1 = a + b;
		temp2 = temp1;

		for (int i = 0; i < tillNumber; i++) {
			if (temp2 < tillNumber) {
				temp3 = temp1 + temp2;
				temp2 = temp1;
				temp1 = temp3;
				System.out.println(temp3);
				i = temp3;
			}
		}
	}

	public void isPrimeNumber(int number) {
		int i = 2;
		boolean isPrime = true;
		while (i < number) {
			for (int j = 2; j < number; j++) {
				if (i != j) {
					if (i % j == 0) {
						System.out.println(i + " is not a prime number.");
						isPrime = false;
						break;
					}
				}
			}
			if (isPrime) {
				System.out.println(i + " is a prime number.");
			}
			isPrime = true;
			i++;
		}
	}

	static {

	}
	/*
	 * int num;
	 * 
	 * public Java_class_A(int number, String name) { num = number;
	 * System.out.println(num); System.out.println(name); }
	 * 
	 * public Java_class_A( Java_class_A name) { System.out.println(name.num); }
	 */

	public void testInherit() {
		System.out.println("class A method called.");
	}
	
	static int fileinitial;
    public Java_class_A(int filename) {
        fileinitial=filename;
        System.out.println(fileinitial);
    }
    
    public Java_class_A() {
    }
    

	public static void main(String... args) {
		
		
		/*instanceof*/
		Java_class_C java_class_C = new Java_class_C();
		System.out.println(java_class_C instanceof Java_class_B);
//		java_class_C.testInherit();
		
		Java_class_B java_class_B = new Java_class_B();
//		java_class_B.testInherit();
		
		Java_class_A java_class_A = new Java_class_A(2);
		java_class_A.isPrimeNumber(50);

		/* Unary operator */
		int test2 = 10;
		System.out.println(++test2);
		System.out.println(test2++);
		System.out.println(--test2);
		System.out.println(test2--);

		int a = 10;
		int b = -10;
		boolean c1 = true;
		boolean d1 = false;
		System.out.println(~a);// -11 (minus of total positive value which starts from 0)
		System.out.println(~b);// 9 (positive of total minus, positive starts from 0)
		System.out.println(!c1);// false (opposite of boolean value)
		System.out.println(!d1);// true

		/*
		 * long passedTimeInSeconds = 0, earlierSecond = 0, currentSecond = 0; long
		 * waitTillTime = Instant.now().getEpochSecond() +26; while(passedTimeInSeconds
		 * < waitTillTime){ passedTimeInSeconds = Instant.now().getEpochSecond();
		 * earlierSecond = passedTimeInSeconds%60+1; currentSecond =
		 * Instant.now().getEpochSecond()% 60 + 1; if(currentSecond > earlierSecond) {
		 * System.out.println("Second: "+earlierSecond); } }
		 */

		ArrayList<String> testArrayToString = new ArrayList<String>();
		testArrayToString.add("one");
		testArrayToString.add("two");
		testArrayToString.add("three");
		String test = testArrayToString.toString();

		System.out.println(testArrayToString);
		System.out.println(testArrayToString.toString().replace("[", "").replace("]", ""));
		System.out.println(test);

		/* Methods in string */
		String txt = "Hello world welcome";

		System.out.println("Length of string " + txt.length());

		System.out.println(txt.toLowerCase());

		System.out.println(txt.toUpperCase());

		boolean yes = txt.contains("o");

		System.out.println(yes);

		System.out.println(txt.replace("l", "A"));

		System.out.println(txt.replaceAll("l", "A"));

		System.out.println(txt.replaceFirst("l", "A"));

		System.out.println(txt.indexOf("w"));

		System.out.println(txt.charAt(6));

		// Math function in java
		System.out.println(Math.max(5, 10));

		System.out.println(Math.PI);

		System.out.println(Math.addExact(5, 100));

		System.out.println((int) (Math.random() * 102));

		// if else
		int time = 20;
		String result = (time < 18) ? "Condition true." : "Condition false";
		System.out.println(result);

		// switch
		String month = "December";

		switch (month) {
		case "January":
			System.out.println("Jan @1");
			break;

		case "February":
			System.out.println("Feb @2");
			break;

		case "March":
			System.out.println("Mar @3");
			break;

		case "Decembe":
			System.out.println("Dec @12");
			break;

		default:
			System.out.println("No matches");
			break;
		}

		// while
		int i = 1;
		while (i <= 5) {
			System.out.println("Value " + i);
			i++;
		}

		// do while
		int j = 1;
		do {
			System.out.println("Value " + j);
			j++;
		} while (j <= 0);

		// Arrays
		String[] cars = { "Volvo", "BMW", "Ford", "Mazda" };

		System.out.println(cars);

		System.out.println(Arrays.toString(cars));

		System.out.println(cars.length);

		System.out.println(cars[1]);

		cars[1] = "Nandan";

		System.out.println(cars[1]);

		for (String car : cars) {
			System.out.println(car);
		}

		// ArrayList
		ArrayList<String> fruitsList = new ArrayList<String>();

		fruitsList.add("Banana");
		fruitsList.add("Dragon fruit");
		fruitsList.add("Apple");
		fruitsList.add("Carrot");

		System.out.println(fruitsList);

		fruitsList.stream().forEach(s -> System.out.println(s));

		System.out.println("*****************************");

		fruitsList.stream().sorted().forEach(s -> System.out.println(s));

		System.out.println("*****************************");

		// Sorting using collecting
		Collections.sort(fruitsList);

		for (String fruit : fruitsList) {
			System.out.println(fruit);
		}

		// Recursion
		int resultValue = sum(10);

		System.out.println("Recursion value is " + resultValue);

		//


		java_class_B.classCalling();

		System.out.println("*****************************");

//Regular expression
		Pattern pattern = Pattern.compile("Java");
		Matcher matcher = pattern.matcher("Nandan is practicing java");

		boolean matchFound = matcher.find();
		System.out.println("*****************************");
		System.out.println((matchFound == true) ? "Text exists" : "Text doesn't exists.");

		String value = "1000";
		int valueFromString = Integer.parseInt(value);
		System.out.println("*****************************");
		System.out.println(valueFromString);

//Convert a string to array list
		String name = "Nandan";

		ArrayList<String> stringToList = new ArrayList<String>(Arrays.asList(name.split("")));

		HashSet<String> noRepitatives = new HashSet<String>();

		for (String string : stringToList) {
			System.out.println(string);
			noRepitatives.add(string.toLowerCase());
		}

		System.out.println(noRepitatives);

		for (String string : noRepitatives) {
			System.out.println(string);
		}

//Hashmap
		HashMap<String, String> capitalCities = new HashMap<String, String>();

//Add keys and values (Country, City)
		capitalCities.put("England", "London");
		capitalCities.put("Germany", "Berlin");
		capitalCities.put("Norway", "Oslo");
		capitalCities.put("USA", "Washington DC");
		System.out.println("*****************************");
		System.out.println(capitalCities);
		System.out.println(capitalCities.get("USA"));
		System.out.println(capitalCities.size());

		for (String string : capitalCities.keySet()) {
			System.out.println(capitalCities.get(string));
		}

//Sets
//HashSet
		HashSet<String> carsHashSet = new HashSet<String>();
		carsHashSet.add("Volvo");
		carsHashSet.add("BMW");
		carsHashSet.add("Ford");
		carsHashSet.add("BMW");
		carsHashSet.add("Mazda");
		carsHashSet.add("Mazda");
		System.out.println("*****************************");
		System.out.println(carsHashSet);

//Linked hashset
		LinkedHashSet<String> carsLinkedHashset = new LinkedHashSet<String>();
		carsLinkedHashset.add("Volvo");
		carsLinkedHashset.add("BMW");
		carsLinkedHashset.add("Ford");
		carsLinkedHashset.add("BMW");
		carsLinkedHashset.add("Mazda");
		carsLinkedHashset.add("Mazda");
		System.out.println("*****************************");
		System.out.println(carsLinkedHashset);

//Tree set
		TreeSet<String> carsTreeSet = new TreeSet<String>();
		carsTreeSet.add("Volvo");
		carsTreeSet.add("BMW");
		carsTreeSet.add("Ford");
		carsTreeSet.add("BMW");
		carsTreeSet.add("Mazda");
		carsTreeSet.add("Mazda");
		System.out.println("*****************************");
		System.out.println(carsTreeSet);

//Maps
//Hash map
		HashMap<String, String> capitalCitiess = new HashMap<String, String>();
		capitalCitiess.put("Norway", "Oslo");
		capitalCitiess.put("England", "London");
		capitalCitiess.put("Germany", "Berlin");
		capitalCitiess.put("Norway", "Oslo");
		capitalCitiess.put("USA", "Washington DC");
		capitalCitiess.put("USAA", null);

		System.out.println("*****************************");
		System.out.println(capitalCitiess);

//Linked hash map
		LinkedHashMap<String, String> capitalCitiesLinked = new LinkedHashMap<String, String>();
		capitalCitiesLinked.put("Norway", "Oslo");
		capitalCitiesLinked.put("England", "London");
		capitalCitiesLinked.put("Germany", "Berlin");
		capitalCitiesLinked.put("Norway", "Oslo");
		capitalCitiesLinked.put("USA", "Washington DC");
		capitalCitiesLinked.put("USAA", null);
		System.out.println("*****************************");
		System.out.println(capitalCitiesLinked);

//hash table
		Hashtable<String, String> capitalCitiesHT = new Hashtable<String, String>();
		capitalCitiesHT.put("Norway", "Oslo");
		capitalCitiesHT.put("England", "London");
		capitalCitiesHT.put("Germany", "Berlin");
		capitalCitiesHT.put("Norway", "Oslo");
		capitalCitiesHT.put("USA", "Washington DC");
		System.out.println("*****************************");
		System.out.println(capitalCitiesHT);

//TreeMap 
		TreeMap<String, String> capitalCitiesTree = new TreeMap<String, String>();
		capitalCitiesTree.put("Norway", "Oslo");
		capitalCitiesTree.put("England", "London");
		capitalCitiesTree.put("Germany", "Berlin");
		capitalCitiesTree.put("Norway", "Oslo");
		capitalCitiesTree.put("USA", "Washington DC");
		System.out.println("*****************************");
		System.out.println(capitalCitiesTree);

//Word reverse
		String word = "Nandan";
		ArrayList<String> wordToList = new ArrayList<String>(Arrays.asList(word.split("")));
		String reverseWord = "";

		for (int k = wordToList.size() - 1; k >= 0; k--) {
			reverseWord = reverseWord + wordToList.get(k);
		}

		System.out.println("*****************************");
		System.out.println(reverseWord);

		String reverseName = "";

		for (int l = word.length() - 1; l >= 0; l--) {
			reverseName = reverseName + word.charAt(l);
		}

		System.out.println("*****************************");
		System.out.println(reverseName);

//count alphabets
		String alphaNum = "aabcdef12345gfhjk";
		int countAlphabets = 0;

		for (int m = 0; m < alphaNum.length(); m++) {

			if (Character.isLetter(alphaNum.charAt(m))) {
				countAlphabets++;
			}

		}
		System.out.println("*****************************");
		System.out.println("Total alphabets are " + countAlphabets);

//Count vowels
		int countVowels = 0;
		TreeMap<Character, Integer> listM = new TreeMap<Character, Integer>();

		for (int n = 0; n < alphaNum.length(); n++) {

			char ch = alphaNum.charAt(n);

			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
				countVowels++;
			}

		}
		System.out.println("*****************************");
		System.out.println("Total vowels are " + countVowels);

//maximum count of repeated letters
		String animalName = "bookkeeper";

		char letter;
		int countL = 0;
		char tempChar = 0;
		int p;

		for (int o = 0; o < animalName.length(); o++) {

			letter = animalName.charAt(o);

			for (p = 0; p < animalName.length(); p++) {
				if (letter == animalName.charAt(p)) {
					countL++;
				}

			}

			tempChar = animalName.charAt(o);
			listM.put(tempChar, countL);
			countL = 0;

		}

		System.out.println("*****************************");
		System.out.println(listM);

//maximum count of repeated letters using list
		String animalNames = "bookkeeper";

		ArrayList<String> repList = new ArrayList<String>(Arrays.asList(animalNames.split("")));

		Collections.sort(repList);

//Count how many strings have 'abc'
		String words = "bac bca bcc caa cab cac cba cbc cca ccb";
		int abcCount = 0;
		String wordsArray[] = words.split(" ");
		String argss[] = { "1", "2" };
		System.out.println(argss.length);
		for (int r = 0; r < wordsArray.length; r++) {

			if (wordsArray[r].contains("a") && wordsArray[r].contains("b") && wordsArray[r].contains("c")) {
				abcCount++;
			}
		}

		System.out.println("*****************************");
		System.out.println("Total words have 'abc' are " + abcCount);

//Garbage collector
		System.out.println("*****************************");
		System.gc();

//Palindrome
		String nm = "Madhu";
		nm.intern();
		StringBuilder sb = new StringBuilder(nm);
		String reverseWordd = sb.reverse().toString();
		if (nm.equals(reverseWordd)) {
			System.out.println("String is palindrome");
		} else {
			System.out.println("*****************************");
			System.out.println("Reverse word is " + reverseWordd);
		}

//Remove duplicates from sorted linked list
		LinkedList<Integer> dupInt = new LinkedList<Integer>();
		dupInt.add(11);
		dupInt.add(11);
		dupInt.add(11);
		dupInt.add(21);
		dupInt.add(43);
		dupInt.add(43);
		dupInt.add(60);

		TreeSet<Integer> noDupInt = new TreeSet<Integer>();

		for (Integer integer : dupInt) {

			noDupInt.add(integer);

		}
		System.out.println("*****************************");
		System.out.println(noDupInt);

//Exercise1
		String obj = "abcdef";
		int length = obj.length();
		char c[] = new char[length];
		obj.getChars(0, length, c, 0);
		CharArrayReader io_2 = new CharArrayReader(c, 0, 3);
		int ii;
		try {
			while ((ii = io_2.read()) != -1) {
				System.out.println("*****************************");
				System.out.print((char) ii);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

//Exercise 2
		int index = 0;
		System.out.println(index);

	}

}
