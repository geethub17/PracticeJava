package practice;

public class SN {

	public static int minDistancte(int[] givenArray, int start, int reqNum) {

		// int a[] = {1,2,3,10,11,2,1};
		// int a[] = {0,1,2,3,10,11,2,1};

		int traverseFromLR = 0, traverseFromRL = 0;

		aa: for (int i = 0; i < givenArray.length; i++) {
			if (givenArray[i] == start) {
				for (int j = i + 1; j < givenArray.length; j++) {
					if (givenArray[j] != reqNum) {
						traverseFromLR++;
					} else {
						break aa;
					}
				}
			}
		}

		System.out.println(traverseFromLR);
		return reqNum;

	}

	public static int minDistancte2(int[] givenArray, int start, int reqNum) {

		// int a[] = {1,2,3,10,11,2,1};
		// int a[] = {0,1,2,3,10,11,2,1};

		int traverseFromLR = 0, startPosition = 0, reqNumPosition = 0;
		boolean found = false, found2 = false;

		for (int i = 0; i < givenArray.length; i++) {
			if (givenArray[i] == start && found == false) {
				startPosition = i;
				found = true;
			}

			if (givenArray[i] == reqNum && found2 == false) {
				reqNumPosition = i;
				found2 = true;
			}
		}

		System.out.println(reqNumPosition - startPosition);
		return reqNum;

	}

	public static int minDistancte3(int[] arr, int x, int y) {

		// int a[] = {1,2,3,10,11,2,1};
		// int a[] = {0,1,2,3,10,11,2,1};

		int idx1 = -1, idx2 = -1, min_dist = Integer.MAX_VALUE;
		for (int i = 0; i < arr.length; i++) {
			// if current element is x then change idx1
			if (arr[i] == x) {
				idx1 = i;
			}
			// if current element is y then change idx2
			else if (arr[i] == y) {
				idx2 = i;
			}
			// if x and y both found in array
			// then only find the difference and store it in
			// min_dist
			if (idx1 != -1 && idx2 != -1)
				min_dist = Math.min(min_dist, Math.abs(idx1 - idx2));
		}

		// if left or right did not found in array
		// then return -1
		if (idx1 == -1 || idx2 == -1)
			return -1;
		// return the minimum distance
		else
			return min_dist;

	}

	public static void main(String[] args) {
//		SN.minDistancte(new int[] { 1, 2, 3, 10, 17, 11, 2, 1 }, 1, 11);
//		SN.minDistancte2(new int[] { 1, 2, 3, 10, 17, 11, 2, 1 }, 1, 11);
		System.out.println(SN.minDistancte3(new int[] { 1, 2, 3, 10, 17, 11, 2, 1 }, 1, 11));

	}

}
