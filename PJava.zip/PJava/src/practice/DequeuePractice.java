package practice;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.PriorityQueue;

public class DequeuePractice {

	public static void main(String[] args) {
		ArrayDeque<String> arrayDeque = new ArrayDeque<String>();
		arrayDeque.add("Nandan1");
		arrayDeque.add("Nandan10");
		arrayDeque.add("Nandan2");
		arrayDeque.add("Nandan3");
		arrayDeque.add("Nandan3");
		arrayDeque.add("Nandan5");
		arrayDeque.add("Nandan4");

		Iterator<String> iterator = arrayDeque.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		
			}
}
