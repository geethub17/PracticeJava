package practice;

public interface InterfaceB {
	
	public void interfaceMthod1();

}
