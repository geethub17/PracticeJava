package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Stack;
import java.util.Vector;

public class CollectionFramework {

	public static void main(String[] args) {

		/* List */

		/* Array list */
		ArrayList<String> arraylist = new ArrayList<String>(Arrays.asList("NandanArrayList", "NandanArrayList2"));
		arraylist.add("NandanArrayList4");
		arraylist.add("NandanArrayList3");
		Iterator<String> iterator = arraylist.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}

//		System.out.println(arraylist.set(2, "Replaced"));
//		System.out.println(arraylist.get(2));

		System.out.println();

		/* Sort */
		Collections.sort(arraylist);
		for (String str : arraylist)
			System.out.println(str);

		System.out.println();

		/* Reverse order */
		ListIterator<String> list1 = arraylist.listIterator(arraylist.size());
		while (list1.hasPrevious()) {
			System.out.println(list1.previous());
		}

		System.out.println();

		/* Linked list */
		LinkedList<String> linkedList = new LinkedList<String>(Arrays.asList("NandanLinkedList", "NandanLinkedList2"));
		linkedList.add("NandanLinkedList3");
		linkedList.add("NandanLinkedList4");
		linkedList.pop();
		Iterator<String> iterator2 = linkedList.iterator();
		while (iterator2.hasNext()) {
			System.out.println(iterator2.next());

		}

		System.out.println();

		/* Vector */
		Vector<Integer> vector = new Vector<Integer>(Arrays.asList(1, 2, 3, 4));
		Iterator<Integer> iterator3 = vector.iterator();
		while (iterator3.hasNext()) {
			System.out.println(iterator3.next());

		}


		/* Stack */
		Stack<Integer> stack = new Stack<Integer>();
		stack.push(1);
		stack.push(2);
		stack.push(3);
		stack.push(4);
		stack.push(5);
		stack.pop();
		Iterator<Integer> iterator4 = stack.iterator();
		while (iterator4.hasNext()) {
			System.out.println(iterator4.next());
		}
		System.out.println(stack);

		
		System.out.println();

		
		/*Set*/
		
		/*HashSet*/
		HashSet<String> hashset = new HashSet<String>();
		hashset.add("Nandan");
		hashset.add("Deepak");
		hashset.add("Deepak");
		hashset.add("Geethu");
		
		Iterator<String> iterator5 = hashset.iterator();
		while(iterator5.hasNext()) {
			System.out.println(iterator5.next());
		}
		System.out.println(hashset);

		
	}
}
