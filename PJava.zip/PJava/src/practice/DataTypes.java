package practice;

public class DataTypes {
	public static void main(String[] args) {
		byte val = 127;
		long a = 100L;
//		System.out.println(a);
		
		char c = 65535;
		
//		System.out.println(c);
		
		int x = 10*20-20; 
        System.out.println(x); 
	}
}
