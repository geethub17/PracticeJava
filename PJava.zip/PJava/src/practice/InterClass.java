package practice;

public class InterClass implements InterfaceB, InterfaceC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void interfaceMthod1() {
		// TODO Auto-generated method stub

	}

}
