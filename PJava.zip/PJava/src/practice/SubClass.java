package practice;

public class SubClass extends SuperClass {
	public void method1() {
		System.out.println("Method1 from sub class.");
	}
	
	public void method2() {
		System.out.println("Method2 from sub class");
	}
	
	public void method3() {
		System.out.println("Method3 from sub class.");
	}
}
