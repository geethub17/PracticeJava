package practice;

public class Java_class_B extends Java_class_A {

	public void methodOfClass() {
		System.out.println("Method of class B");
	}

	public void testInherit() {
		System.out.println("class B method called.");
	}

	public void classCalling() {

		Java_class_A java_class_A = new Java_class_A();

		Java_class_B java_class_b = new Java_class_B();

		Java_class_C java_class_c = new Java_class_C();

		System.out.println(Java_class_A.sum(6));

		System.out.println(java_class_A.getMyName());

		java_class_A.setMyName("Nandan");

		System.out.println(java_class_A.getMyName());

		java_class_b.setMyName("Reading...");

		System.out.println(java_class_b.getMyName());

		java_class_A.methodOfClass();

		java_class_b.methodOfClass();

	}

}
