package practice;

public class Java_class_C extends Java_class_B {

	public Java_class_C() {
		System.out.println("Constructor called.");
	}
	
	{
		System.out.println("Instance intialtion called.");
	}
	
	static {
		System.out.println("static block.");
	}

	public static void main(String[] args) {
		new Java_class_C();
		new Java_class_C();

	}
}
