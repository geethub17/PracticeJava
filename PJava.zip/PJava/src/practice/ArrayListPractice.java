package practice;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.ListIterator;

public class ArrayListPractice {
	public static void main(String[] args) {

		ArrayList<String> collection = new ArrayList<String>();
		collection.add("Nandan");
		collection.add("Geethu");
		collection.addAll(Arrays.asList("Geethanandan", "Geethanandan", "Nandan"));

//		System.out.println(collection);
//		System.out.println(collection.contains("Geethanandan"));
//		System.out.println(collection.contains("Geet"));
//		System.out.println(collection.equals(collection));
//		System.out.println(collection.equals(new ArrayList<Integer>(Arrays.asList(1,2,3))));
//		collection.forEach(n -> System.out.println(n));
//		collection.forEach(n -> System.out.println(n.contains("Geet")));
//		System.out.println(collection.getClass());
//		System.out.println(collection.isEmpty());
//		Iterator< String> iterator = collection.iterator();
//		while(iterator.hasNext()) {
//			System.out.println(iterator.next());
//		}
//		collection.removeAll(Arrays.asList("Geethanandan"));
//		System.out.println(collection);

		/* Remove duplicate elements for Array list. Convert the list to set */
//		Collection<String> set = new HashSet<String>(collection);
//		System.out.println(set);

		/* How to reverse array list */
//		ListIterator<String> iterator = collection.listIterator(collection.size());
//		while (iterator.hasPrevious()) {
//			System.out.println(iterator.previous());
//		}
//		Collections.reverse(collection);
//		System.out.println(collection);
//		 System.out.println(collection.size());
		
		System.out.println(collection);
//		Collections.reverse(collection);
		Collections.asLifoQueue(new ArrayDeque<>(collection));
		System.out.println(collection);
		
		String s1= "test1,test2,test3";
		String elms[] = s1.split(",");

		List<String> arrayList = new ArrayList<String>(Arrays.asList(elms));
		List<String> arrayList2 = new ArrayList<String>(Arrays.asList(s1));

		System.out.println(arrayList);
		System.out.println(arrayList2);
	}
}
