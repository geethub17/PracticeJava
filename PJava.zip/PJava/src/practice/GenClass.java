package practice;

import java.util.ArrayList;
import java.util.List;

public class GenClass<T> {

	List<T> list = new ArrayList<T>();

	public void add(T object) {
		list.add(object);
	}

	public List<T> getList() {
		return list;
	}
}
