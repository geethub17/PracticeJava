package practice;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;

public class HashSetPractice {

	public static void main(String[] args) {
		HashSet<String> hashSet = new HashSet<String>();
		hashSet.add("Nandan1");
		hashSet.add("Nandan2");
		hashSet.add("Nandan2");
		hashSet.add("Nandan3");
		hashSet.add("Nandan4");
//		hashSet.add(null);
//		hashSet.add(null);
//		hashSet.forEach(n -> System.out.println(n));
//		System.out.println(hashSet);
//		System.out.println(hashSet);
//
//		for (String str : hashSet) {
//			if (str != null && str.equals("Nandan1")) {
//				System.out.println(str);
//			}
//		}
//		Iterator<String> listIterator = hashSet.iterator();
//		while (listIterator.hasNext()) {
//			System.out.println(listIterator.next());
//		}
		System.out.println(hashSet);

		Collections.asLifoQueue(new ArrayDeque<>(hashSet));
		System.out.println(hashSet);
	}
}
