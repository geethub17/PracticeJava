package practice;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

public class TreeMapPractice {

	public static void main(String[] args) {
		TreeMap<Integer, String> treeMap = new TreeMap<Integer, String>();
		treeMap.put(1, "Nandan1");
		treeMap.put(2, "Nandan2");
		treeMap.put(3, "Nandan3");
		treeMap.put(4, "Nandan4");
		treeMap.put(7, "Nandan7");
		treeMap.put(10, "Nandan10");
		treeMap.put(10, "Nandan10");

//		for (Map.Entry m : treeMap.entrySet()) {
//			System.out.println(m.getKey() + " " + m.getValue());
//		}
//
//		treeMap.forEach((k, v) -> {
//			System.out.println(k);
//			System.out.println(v);
//		});
//
//		Set<Entry<Integer, String>> entries = treeMap.entrySet();
//		Iterator<Entry<Integer, String>> iterator = entries.iterator();
//		while (iterator.hasNext()) {
//			Entry<Integer, String> keyAndValue = iterator.next();
//			System.out.println(keyAndValue.getKey() + " & " + keyAndValue.getValue());
//		}

		System.out.println(treeMap.firstEntry());
		System.out.println(treeMap.firstKey());
		System.out.println(treeMap.firstKey());
		System.out.println(treeMap.firstKey());
		
		System.out.println(treeMap);
	}
}
