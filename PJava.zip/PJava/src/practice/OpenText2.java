package practice;

public class OpenText2 {

	public static String solution2(String S) {

		String ans = S.charAt(0) + "" + S.charAt(1);

		for (int i = 2; i < S.length(); ++i) {
			if (S.charAt(i) != S.charAt(i - 1) || S.charAt(i) != S.charAt(i - 2)) {
				ans += (S.charAt(i));
			}
		}
		return ans;
	}

	public static int solution(String S) {

		System.out.println(solution("baaabbaabbba")); // 2
		System.out.println(solution("baaaaa")); // 1
		System.out.println(solution("baabab")); // 0

		if (S == null || S.isEmpty()) {
			return 0;
		}
		if (S.length() < 3)
			return 0;

		StringBuilder s = new StringBuilder(S);
		int answer = 0;
		int curr = 1;
		for (int i = 1; i < s.length(); i++) {
			if (s.charAt(i) != s.charAt(i - 1)) {
				curr = 1;
			} else {
				curr++;
			}
			if (curr == 3) {
				if (i == s.length() - 1) {
					answer++;
					break;
				} else if (s.charAt(i + 1) == s.charAt(i)) {
					answer++;
					if (s.charAt(i) == 'a') {
						s.setCharAt(i, 'b');
					} else {
						s.setCharAt(i, 'a');
					}
				} else {
					answer++;
					if (s.charAt(i) == 'a') {
						s.setCharAt(i - 1, 'b');
					} else {
						s.setCharAt(i - 1, 'a');
					}
				}
				curr = 1;
			}
		}
		return answer;
	}

	public static void main(String[] args) {
		System.out.println(solution2("uuuuxaaaaxuuu")); // uuxaaxuu
		System.out.println(solution2("eedaaad")); // eedaad
		System.out.println(solution2("xxxtxxx")); // xxtxx
	}
}
