package practice;

abstract class UseAbstaction extends AbstractClass implements Interface_A {

	@Override
	String test() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void interfaceMthod1() {
		// TODO Auto-generated method stub

	}

	@Override
	public void interfaceMthod2() {
		// TODO Auto-generated method stub

	}

	@Override
	public void interfaceMthod3() {
		// TODO Auto-generated method stub

	}

}
