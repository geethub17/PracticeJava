package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Generics {

	public static void genericClassExample() {
		GenClass<Integer> genClass = new GenClass<Integer>();
		genClass.add(10);
		System.out.println(genClass.getList()); // [10]

		GenClass<String> genClass2 = new GenClass<String>();
		genClass2.add("Nandan");
		System.out.println(genClass2.getList()); // [Nandan]
	}

	public static <E> void printElements(E[] elements) {
		for (E e : elements) {
			System.out.println(e);
		}
	}

	public static <T> List<?> createList(T[] elements) {
		return new ArrayList<T>(Arrays.asList(elements));
	}

//	public static void printNumbes(List<? extends Number> list) {
//		for (Object e : list ) {
//			System.out.println(e);
//		}
//	}

//	public static void printNumbes(List<?> list) {
//		for (Object e : list) {
//			System.out.println(e);
//		}
//	}

	public static void printNumbes(List<? super Integer> list) {
		for (Object e : list ) {
			System.out.println(e);
		}
	}

	public static void main(String[] args) {
//		genericClassExample();
//		printElements(new String[] { "Nandan", "Nandan2", "Nandan3" });
//		printElements(new Integer[] { 1, 2, 3, 4, 5, 6 });

//		System.out.println(createList(new String[] { "Nandan", "Nandan2", "Nandan3" })); // [Nandan, Nandan2, Nandan3]
//		System.out.println(createList(new Integer[] { 1, 2, 3, 4, 5, 6 })); // [1, 2, 3, 4, 5, 6]
		printNumbes(new ArrayList<Integer>(Arrays.asList(1, 2, 3)));
		printNumbes(new ArrayList<Object>(Arrays.asList(1, 2, 3)));

//		printNumbes(new ArrayList<String>(Arrays.asList("1", "2", "3")));
//		printNumbes(new ArrayList<Double>(Arrays.asList(0.1, 0.2, 0.3)));

	}
}
