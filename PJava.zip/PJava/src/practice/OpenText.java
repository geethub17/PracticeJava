package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class OpenText {

	public int solution(String S) {
		ArrayList<String> list = new ArrayList<String>(Arrays.asList(S.split("")));
		Set<String> validated = new HashSet<String>();
		int totalCharacters = 0;
		int remove = 0;
		String temp = "";
		for (int i = 0; i < list.size(); i++) {
			temp = list.get(i).toString();
			if (!validated.contains(temp)) {
				for (int j = 0; j < list.size(); j++) {
					if (temp.equalsIgnoreCase(list.get(j).toString()))
						totalCharacters++;
				}
				if (totalCharacters % 2 == 1) {
					remove++;
				}
				totalCharacters = 0;
			}
			validated.add(temp);
		}
		return remove;

	}

	public static void main(String[] args) {
		OpenText openText = new OpenText();
		System.out.println(openText.solution("ervervige"));
		System.out.println(openText.solution("aaabab"));
		System.out.println(openText.solution("aaaa"));
		System.out.println(openText.solution("acbd"));

	}
}
