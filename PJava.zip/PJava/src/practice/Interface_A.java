package practice;

public interface Interface_A {

	int i = 10;

	void interfaceMthod1();

	public void interfaceMthod2();

	void interfaceMthod3();

	void interfaceMthod4();

	default void log(String str) {
		System.out.println("I1 logging::" + str);
	}

	public static void doStuff() {
		System.out.println("This is not default implementation");
	}
	
	public static void main(String[] args) {
		System.out.println("Test");
	}
}
