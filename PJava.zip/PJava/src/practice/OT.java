package practice;

public class OT {

	public static String removeConsecutive(String s) {

		String temp = s.charAt(0) + "" + s.charAt(1);

		for (int i = 2; i < s.length(); i++) {

			if (s.charAt(i) != s.charAt(i - 1) || s.charAt(i) != s.charAt(i - 2)) {
				temp = temp + s.charAt(i);
			}
		}
		return temp;
	}

	public static void main(String[] args) {
		System.out.println(removeConsecutive("eedaaad"));
	}
}
