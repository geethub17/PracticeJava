package practice;

import java.util.HashSet;
import java.util.Set;

public class SkillSoft {

	public static void printAfterA(String s) {

		int length = s.length();

//		for (int i = 1; i < length; i++) {
//			if (s.charAt(i - 1) == 'a') {
//				System.out.println(s.charAt(i));
//			}
//		}
		
		Set<Character> set = new HashSet<Character>();
		Set<Character> duplicates = new HashSet<Character>();
		
		for (int i = 0; i < length; i++) {
			if(!set.contains(s.charAt(i))) {
				set.add(s.charAt(i));
			}else {
				duplicates.add(s.charAt(i));
			}
		}
		System.out.println(duplicates);
	}
	
	public static void main(String[] args) {
		printAfterA("Geethanandan");
	}
}
