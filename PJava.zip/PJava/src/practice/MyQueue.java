package practice;

import java.util.Stack;

public class MyQueue {

	/* https://leetcode.com/problems/implement-queue-using-stacks/ */
	Stack<Integer> s;
	Stack<Integer> s1;

	public MyQueue() {
		s = new Stack<>();
		s1 = new Stack<>();
	}

	public void push(int x) {
		s.push(x);
	}

	public int pop() {
		if (s1.isEmpty()) {
			while (!s.isEmpty()) {
				s1.push(s.pop());
			}
		}
		return s1.pop();
	}

	public int peek() {
		if (s1.isEmpty()) {
			while (!s.isEmpty()) {
				s1.push(s.pop());
			}
		}
		return s1.peek();
	}

	public boolean empty() {
		return s1.isEmpty() && s.isEmpty();
	}

	

	public static void main(String[] args) {
		MyQueue myQueue = new MyQueue();
		myQueue.push(1); // queue is: [1]
		myQueue.push(2); // queue is: [1, 2] (leftmost is front of the queue)
		myQueue.peek(); // return 1
		myQueue.pop(); // return 1, queue is [2]
		System.out.println(myQueue.empty());// return false
	}
}
