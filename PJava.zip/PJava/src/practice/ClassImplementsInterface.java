package practice;

public class ClassImplementsInterface implements Interface_A {

	@Override
	public void interfaceMthod1() {
		System.out.println("I am method 1.");

	}

	@Override
	public void interfaceMthod2() {
		// TODO Auto-generated method stub

	}

	@Override
	public void interfaceMthod3() {
		// TODO Auto-generated method stub

	}

	public static void main(String[] args) {
//		Interface_A.i = 100; //Interface variables are public static and final
		Interface_A.doStuff();

		ClassImplementsInterface ci = new ClassImplementsInterface();
		ci.interfaceMthod1();
		ci.log("Testing default method");

	}

	@Override
	public void interfaceMthod4() {
		// TODO Auto-generated method stub

	}

}
