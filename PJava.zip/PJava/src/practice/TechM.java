package practice;

public class TechM {

	public static void main(String[] args) {

	}
}
