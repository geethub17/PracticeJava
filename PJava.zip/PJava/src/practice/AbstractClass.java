package practice;

abstract class AbstractClass implements Interface_A {

	 abstract void printStatus();

	abstract String test();

	public static void printNumber() {
		System.out.println("I am 17");
	}

	public void printName() {
		System.out.println("I am nandan..");
	}

}
