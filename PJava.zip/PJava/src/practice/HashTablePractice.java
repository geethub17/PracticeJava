package practice;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashTablePractice {

	public static void main(String[] args) {

		Hashtable<Integer, String>hashtable = new Hashtable<Integer, String>();
		hashtable.put(1, "Nandan1");
		hashtable.put(2, "Nandan2");
		hashtable.put(3, "Nandan3");
		hashtable.put(4, "Nandan4");
		hashtable.put(7, "Nandan7");
		hashtable.put(10, "Nandan10");
		hashtable.put(10, "Nandan10");
//		hashtable.put(11, null);
		
		

		System.out.println(hashtable);
//		
//		for (Map.Entry m : hashtable.entrySet()) {
//			System.out.println(m.getKey() + " " + m.getValue());
//		}
//
//		hashtable.forEach((k, v) -> {
//			System.out.println(k);
//			System.out.println(v);
//		});
//
//		Set<Entry<Integer, String>> entries = hashtable.entrySet();
//		Iterator<Entry<Integer, String>> iterator = entries.iterator();
//		while (iterator.hasNext()) {
//			Entry<Integer, String> keyAndValue = iterator.next();
//			System.out.println(keyAndValue.getKey() + " & " + keyAndValue.getValue());
//		}
	}
}
