package practice;

public class Aclass extends AbstractClass {

	@Override
	void printStatus() {
	}

	@Override
	String test() {
		return null;
	}

	public static void main(String[] args) {
		AbstractClass.printNumber();
		Aclass ac = new Aclass();
		ac.printName();
	}

	@Override
	public void interfaceMthod1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void interfaceMthod2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void interfaceMthod3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void interfaceMthod4() {
		// TODO Auto-generated method stub
		
	}
}
