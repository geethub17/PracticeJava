package practice;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class SkillSoft2 {

	public static Integer commonNumber(int a[], int b[], int c[]) {

		Map<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (int i : a) {
			map.put(i, 1);
		}

		for (int i : b) {
			map.put(i, 2);
		}

		for (int i : c) {
			if (map.containsKey(i) && map.get(i) == 2) {
				return i;
			}
		}
		return null;
	}

	public static Integer commonNumber2(int a[], int b[], int c[]) {

		Set<Integer> set = new HashSet<Integer>(Arrays.stream(a).boxed().collect(Collectors.toList()));
		Set<Integer> set2 = new HashSet<Integer>(Arrays.stream(b).boxed().collect(Collectors.toList()));

		for (Integer i : c) {
			if (set.contains(i) && set2.contains(i)) {
				return i;
			}
		}
		return null;
	}

	public static void main(String[] args) {
		System.out.println(commonNumber(new int[] { 2, 3, 6, 8, 8, 20, 26 }, new int[] { 2, 5, 9, 20, 7, 100 },
				new int[] { 1, 3, 8, 17, 20, 500 }));

		System.out.println(commonNumber(new int[] { -2, 3, 6, 8, 8, 20, 26 }, new int[] { -2, 5, 9, 20, 7, 100 },
				new int[] { -2, 1, 3, 8, 17, 20, 500 }));

		System.out.println(
				commonNumber(new int[] {}, new int[] { -20, -9, -7, -5, -2 }, new int[] { 1, 2, 3, 8, 17, 20, 500 }));

//		System.out.println(
//				commonNumber(new int[] {32585885588588555555555555555555555555555555555555555555555}, new int[] { -20, -9, -7, -5, -2 }, new int[] { 1, 2, 3, 8, 17, 20, 500 }));

		System.out.println(commonNumber(new int[] {}, new int[] {}, new int[] {}));

		System.out.println(commonNumber(new int[] { 1 }, new int[] { 2 }, new int[] { 3 }));

	}

}
