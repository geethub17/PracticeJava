package practice;

import java.util.LinkedHashSet;

public class LinkedHashSetPractice {

	public static void main(String[] args) {
		LinkedHashSet<String> linkedHashSet = new LinkedHashSet<String>();
		linkedHashSet.add("Nandan4");
		linkedHashSet.add("Nandan4");
		linkedHashSet.add("Nandan3");
		linkedHashSet.add("Nandan2");
		linkedHashSet.add("Nandan1");
		linkedHashSet.add("Nandan8");
		linkedHashSet.add("Nandan9");
		linkedHashSet.add(null);
		linkedHashSet.add(null);
		System.out.println(linkedHashSet);
		
	}
}
