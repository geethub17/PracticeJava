package practice;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.PriorityQueue;

public class PriorityQueuePractice {

	public static void main(String[] args) {
		PriorityQueue<String> priorityQueue = new PriorityQueue<String>();
		priorityQueue.add("Nandan1");
		priorityQueue.add("Nandan10");
		priorityQueue.add("Nandan2");
		priorityQueue.add("Nandan3");
		priorityQueue.add("Nandan3");
		priorityQueue.add("Nandan5");
		priorityQueue.add("Nandan4");

		System.out.println(priorityQueue);

		Iterator<String> iterator = priorityQueue.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		System.out.println(priorityQueue.poll());
		System.out.println(priorityQueue);

	}
}
