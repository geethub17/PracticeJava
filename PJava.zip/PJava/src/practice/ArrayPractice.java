package practice;

import java.util.Arrays;

public class ArrayPractice {

	public void arrayDeclaration() {
		int a[] = new int[5];
		a[0] = 10;
		a[1] = 20;
		a[2] = 70;
		a[3] = 40;
		a[4] = 50;

		for (int i = 0; i < a.length; i++)
			System.out.println(a[i]);

		int b[] = { 1, 2, 3, 4, 5 };

		for (int i = 0; i < b.length; i++)
			System.out.println(b[i]);

		int[] c = { 1, 2, 3, 4, 5 };
		for (int i = 0; i < c.length; i++)
			System.out.println(c[i]);

		Integer[] d = { 6, 7, 8, 9, 10 };
		for (int i = 0; i < d.length; i++)
			System.out.println(d[i]);

		Integer[] e = d.clone();
		for (int i = 0; i < e.length; i++)
			System.out.println(e[i]);

		System.out.println(c.getClass());
		System.out.println(c.getClass().getName());

//		Arrays.cop
	}

	public void multidimenssionalArray() {
		int a[][] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };

		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				System.out.print(a[i][j]);
			}
			System.out.println();
		}

		int b[][] = Arrays.copyOfRange(a, 0, 2);

		for (int i = 0; i < b.length; i++) {
			for (int j = 0; j < b.length; j++) {
				System.out.print(b[i][j]);
			}
			System.out.println();
		}

	}

	public void multiplicationOfMultiDimenssionalArray() {

		int a[][] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
		int b[][] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
		int c[][] = new int[3][3];
		
//		https://static.javatpoint.com/cpp/images/matrix-multiplication-in-cpp1.png

		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < b.length; j++) {
				for (int k = 0; k < c.length; k++) {
					c[i][j] += a[i][k] * b[k][j];
				}
			}
		}		
		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c.length; j++) {
				System.out.print(c[i][j]+" ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		practice.ArrayPractice arrayPractice = new practice.ArrayPractice();
//		arrayPractice.arrayDeclaration();
//		arrayPractice.multidimenssionalArray();
		arrayPractice.multiplicationOfMultiDimenssionalArray();
	}
}
