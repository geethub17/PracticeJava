package practice;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.ListIterator;
import java.util.Vector;

public class VectorPractice {

	public static void main(String[] args) {
		Vector<String> vector = new Vector<String>(
				Arrays.asList("Nandan1", "Nandan2", "Nandan3", "Nandan3", "Nandan4"));
		ListIterator<String> listIterator = vector.listIterator(vector.size());
		while (listIterator.hasPrevious()) {
			System.out.println(listIterator.previous());

		}
		

		Enumeration<String> enumeration = vector.elements();
		while (enumeration.hasMoreElements()) {
			System.out.println(enumeration.nextElement());
		}
		String[] array = new String[5];
		vector.copyInto(array);
		System.out.println(Arrays.asList(array));
		
		
	}

}
