package practice;

public class StringClass {

	public static void main(String[] args) {
		
		String s1 = "abc";
		StringBuffer s2 = new StringBuffer(s1);
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s2.toString()));

		String str = new String("Welcome to JavaTpoint");
		String str1 = new String("Welcome to JavaTpoint");
		System.out.println(str1.intern() == str.intern()); // prints true

//		String s1 = "abc";
//		String s2 = new String("abc");
//		System.out.print(s1 == s2);

		System.out.println("Geethu".compareTo("Nandan")); // -7

		String s = "Java String Quiz";
		System.out.println(s.substring(5, 12));//

		/* String buffer */
		StringBuffer stringBuffer = new StringBuffer("String buffer");
		System.out.println(stringBuffer);

//		stringBuffer.append(" is mutable."); // Returns "String buffer is mutable."

//		stringBuffer.insert(0, "INSERT"); // Returns "INSERTString buffer is mutable."

//		stringBuffer.replace(0, 2, "T"); //Returns "Tring buffer is mutable."

//		stringBuffer.delete(0, 2); //Returns "ring buffer is mutable."

//		stringBuffer.reverse(); //Returns ".elbatum si reffub gnirtS"

		System.out.println(stringBuffer.capacity());

		/* String builder */
		StringBuilder stringBuilder = new StringBuilder("String builder");

//		stringBuilder.append(" is mutable."); // Returns "String buffer is mutable."

//		stringBuilder.insert(0, "INSERT"); // Returns "INSERTString buffer is mutable."

//		stringBuilder.replace(0, 2, "T"); //Returns "Tring buffer is mutable."

//		stringBuilder.delete(0, 2); //Returns "ring buffer is mutable."

//		stringBuilder.reverse(); //Returns ".elbatum si reffub gnirtS"

		System.out.println(stringBuilder);

//		stringBuffer.eq

		String a = "abc";

	}
}
