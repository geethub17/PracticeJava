package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class JavaProblems {

	public static void main(String[] args) {
	}

	/* https://leetcode.com/problems/guess-number-higher-or-lower/ */
	public static int guessNumber(int n) {
		System.out.println(guessNumber(10));

		int start = 1, end = n, guess = 0;
		while (start <= end) {
			int mid = start + (end - start) / 2;
			guess = guess(mid);
			if (guess == -1) {
				end = mid;
			} else if (guess == 1) {
				start = mid + 1;
			} else {
				return mid;
			}
		}
		return 1;
	}

	public static int guess(int n) {
		if (n > 6) {
			return -1;
		}
		if (n < 6) {
			return 1;
		}
		return 0;
	}

	/* https://leetcode.com/problems/counting-bits/ */
	public static int[] countBits(int n) {

		System.out.println(countBits(2));

		int[] ans = new int[n + 1];

		if (n == 0)
			return ans;

		int i = 1;

		while (i <= n) {
			ans[i] = Integer.toBinaryString(i).replaceAll("0", "").length();
			i++;
		}
		return ans;
	}

	/* https://leetcode.com/problems/first-bad-version/ */
	public static int firstBadVersion(int n) {

		System.out.println(firstBadVersion(2126753390));

		int start = 1, end = n;
		while (start < end) {
			int mid = start + (end - start) / 2;
			if (!isBadVersion(mid))
				start = mid + 1;
			else
				end = mid;
		}
		return start;
	}

	public static boolean isBadVersion(int n) {
		if (n == 1702766719) {
			return true;
		}
		return false;
	}

	/* https://leetcode.com/problems/add-digits/ */
	public static int addDigits(int num) {

		System.out.println(addDigits(38));
		System.out.println(addDigits(0));

		if (num < 10) {
			return num;
		}

		int ans = 0;

		while (true) {
			while (num > 0) {
				ans += num % 10;
				num = num / 10;
			}
			if (ans < 10) {
				return ans;
			}
			num = ans;
			ans = 0;
		}
	}

	/* https://leetcode.com/problems/multiply-strings/ */
	public static String multiply(String num1, String num2) {
		System.out.println(multiply("12", "96"));
		System.out.println(multiply("123", "456"));
		System.out.println(multiply("2", "3"));

		if (num1.charAt(0) - '0' == 0 || num2.charAt(0) - '0' == 0) {
			return "0";
		}

		int product = 0;
		int carry = 0;
		StringBuilder sb = new StringBuilder();
		int[] res = new int[num1.length() + num2.length()];

		for (int i = num1.length() - 1; i >= 0; i--) {
			for (int j = num2.length() - 1; j >= 0; j--) {
				int n1 = num1.charAt(i) - '0';
				int n2 = num2.charAt(j) - '0';

				res[i + j] += n1 * n2;
			}
		}

		for (int i = res.length - 1; i >= 0; i--) {
			product = (res[i] + carry) % 10;
			carry = (res[i] + carry) / 10;

			if (i == res.length - 1 && res[i] == 0) {
				continue; // avoid leading zero
			}
			sb.append(product);
		}

		if (carry != 0) {
			sb.append(carry);
		}

		return sb.reverse().toString();

//		int n1 = 0, n2 = 0;
//		int len1 = num1.length(), len2 = num2.length();
//		int cv;
//
//		for (int i = 0; i < len1; i++) {
//			cv = num1.charAt(i) - 48;
//			if (i + 1 == len1) {
//				n1 += cv;
//				break;
//			}
//			n1 += cv;
//			n1 *= 10;
//		}
//
//		for (int i = 0; i < len2; i++) {
//			cv = num2.charAt(i) - 48;
//			if (i + 1 == len2) {
//				n2 += cv;
//				break;
//			}
//			n2 += cv;
//			n2 *= 10;
//		}
//
//		return String.valueOf(n1 * n2);

	}

	/* https://leetcode.com/problems/permutations-ii/ */
	List<List<Integer>> ans;

	public List<List<Integer>> permuteUnique(int[] nums) {

		JavaProblems jp = new JavaProblems();
		jp.permuteUnique(new int[] { 1, 1, 2 });
		ans = new ArrayList<List<Integer>>();
		generatePermutations(nums, 0);
		System.out.println(ans);
		return ans;
	}

	public void generatePermutations(int[] nums, int start) {

		if (start == nums.length - 1) {
			ans.add(addToList(nums));
			return;
		}

		Set<Integer> set = new HashSet<>();
		for (int i = start; i < nums.length; i++) {
			if (set.add(nums[i])) {
				int tmp = nums[start];
				nums[start] = nums[i];
				nums[i] = tmp;
				generatePermutations(nums, start + 1);
				nums[i] = nums[start];
				nums[start] = tmp;
			}
		}
	}

	public List<Integer> addToList(int[] nums) {
		List<Integer> list = new ArrayList<Integer>();
		for (int i : nums) {
			list.add(i);
		}
		return list;
	}

	/* towerOfHanoi */
	public static void towerOfHanoi(int n, char from_rod, char to_rod, char aux_rod) {

		int N = 3;

		// A, B and C are names of rods
		towerOfHanoi(N, 'A', 'C', 'B');

		System.out.println("The n value is: " + n);

		if (n == 0) {
			return;
		}
		towerOfHanoi(n - 1, from_rod, aux_rod, to_rod);
		System.out.println("Move disk " + n + " from rod " + from_rod + " to rod " + to_rod);
		towerOfHanoi(n - 1, aux_rod, to_rod, from_rod);

	}

	/* https://leetcode.com/problems/rotate-image/ */
	public static void rotate(int[][] matrix) {

		rotate(new int[][] { { 5, 1, 9, 11 }, { 2, 4, 8, 10 }, { 13, 3, 6, 7 }, { 15, 14, 12, 16 } });
		rotate(new int[][] { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } });

		int len = matrix.length;
		int n, swap;
		int temp;

		for (int i = 0; i < len; i++) {
			for (int j = i + 1; j < len; j++) {
				temp = matrix[i][j];
				matrix[i][j] = matrix[j][i];
				matrix[j][i] = temp;
			}
		}

		for (int i = 0; i < len; i++) {
			n = len - 1;
			for (int j = 0; j < len; j++) {
				temp = matrix[i][j];
				matrix[i][j] = matrix[i][n];
				matrix[i][n--] = temp;
				swap = Math.abs(j - n);
				if (swap == 1 | swap == 0)
					break;
			}
		}

		System.out.println(String.valueOf(matrix));
	}

	/* https://leetcode.com/problems/merge-sorted-array/ */
	public static void merge(int[] nums1, int m, int[] nums2, int n) {

		merge(new int[] { 1, 2, 3, 0, 0, 0 }, 3, new int[] { 2, 5, 6 }, 3);
		merge(new int[] { -50, -48, -47, -47, -46, -44, -43, -43, -41, -39, -38, -37, -37, -37, -33, -33, -32, -31, -29,
				-29, -27, -26, -26, -26, -25, -25, -24, -24, -23, -22, -22, -22, -18, -17, -17, -14, -14, -11, -11, -11,
				-6, -5, -5, -5, -5, -4, -1, 0, 2, 2, 2, 2, 5, 6, 7, 7, 9, 10, 13, 13, 14, 14, 18, 21, 21, 21, 22, 24,
				24, 24, 25, 26, 26, 29, 29, 29, 30, 30, 31, 31, 32, 33, 34, 34, 34, 35, 38, 40, 41, 42, 43, 44, 44, 46,
				46, 47, 47, 48, 49, 49 }, 100, new int[] {}, 0);
		merge(new int[] { 1 }, 1, new int[] {}, 0);
		merge(new int[] { -1, 0, 0, 3, 3, 3, 0, 0, 0 }, 6, new int[] { 1, 2, 2 }, 3);
		merge(new int[] { 0 }, 0, new int[] { 1 }, 1);

		int len = m + n - 1;
		int j = 0;

		if (n == 0) {
			// do nothing just return nums1 as that is already in sorted order.
		} else {
			while (len >= 0) {
				if (nums1[len] == 0) {
					nums1[len--] = nums2[j];
					j++;
					if (j == n)
						break;
				}
			}
			Arrays.sort(nums1);
		}
	}

	/* https://leetcode.com/problems/group-anagrams/ */
	public static List<List<String>> groupAnagrams(String[] strs) {

		System.out.println(groupAnagrams(new String[] { "tttti", "tttit", "hhhhu", "hhhuh", "hhuhh", "tittt" }));
		System.out.println(groupAnagrams(new String[] { "eat", "tea", "tan", "ate", "nat", "bat" }));
		System.out.println(
				groupAnagrams(new String[] { "duh", "ill", "may", "cab", "tin", "pew", "buy", "bar", "max", "doc" }));
		System.out.println(groupAnagrams(new String[] { "" }));
		System.out.println(groupAnagrams(new String[] { "a" }));

//		if (strs == null || strs.length == 0)
//			return new ArrayList<>();
//		Map<String, List<String>> map = new HashMap<>();
//		for (String s : strs) {
//			char[] ca = new char[26];
//			for (char c : s.toCharArray())
//				ca[c - 'a']++;
//			String keyStr = String.valueOf(ca);
//			if (!map.containsKey(keyStr))
//				map.put(keyStr, new ArrayList<>());
//			map.get(keyStr).add(s);
//		}
//		return new ArrayList<>(map.values());

		Map<String, List<String>> map = new HashMap<String, List<String>>();
		int arrayLength = strs.length, wordLength;
		String word = null, temp;
		char[] ca = null;

		for (int i = 0; i < arrayLength; i++) {
			word = strs[i];
			wordLength = word.length();
			ca = new char[26];
			for (int j = 0; j < wordLength; j++) {
				ca[word.charAt(j) - 'a']++;
			}
			temp = String.valueOf(ca);
			System.out.println(temp);
			if (!map.containsKey(temp)) {
				map.put(temp, new ArrayList<>());
			}
			map.get(temp).add(word);
		}
		return new ArrayList<>(map.values());
	}

	/* https://leetcode.com/problems/search-insert-position/ */
	public static int searchInsert(int[] nums, int target) {

		System.out.println(searchInsert(new int[] { 1, 3, 5, 6 }, 7));// 4
		System.out.println(searchInsert(new int[] { 1, 3, 5, 6 }, 2));// 1
		System.out.println(searchInsert(new int[] { 1, 3, 6, 5, 6 }, 4));// 2
		System.out.println(searchInsert(new int[] { 1, 3, 4, 5, 6 }, 5));// 3
		System.out.println(searchInsert(new int[] { 1, 3, 5, 6 }, 5));// 2

		int i = 0, j = nums.length - 1;

		for (i = 0; i < nums.length | j > 0; i++, j--) {
			if (nums[i] == target) {
				return i;
			} else if (nums[i] > target) {
				return i;
			}

			if (nums[j] == target) {
				return j;
			}
		}
		return nums.length;
	}

	/* https://leetcode.com/problems/3sum/ */
	public static List<List<Integer>> threeSum(int[] arr) {

		System.out.println(threeSum(new int[] { -1, 0, 1, 0 }));
		System.out.println(threeSum(new int[] { -1, 0, 1, 2, -1, -4 }));
		System.out.println(threeSum(new int[] { 0, 0, 0 }));
		System.out.println(threeSum(new int[] { 0, 0, 0, 0, 0, 0 }));
		System.out.println(threeSum(new int[] { 0, 0, 0, 0, 0, 1 }));
		System.out.println(threeSum(new int[] { -5, 5, 0, 3, 1, -2, -2, 4, -3 }));
		System.out.println(threeSum(new int[] { 0, 1, 1 }));

		Set<List<Integer>> result = new HashSet<>();

		if (arr == null || arr.length < 3)
			return new ArrayList<>(result);

		Arrays.sort(arr); // Sort the elements

		int size = arr.length;

		for (int i = 0; i < size - 2; i++) {

			int left = i + 1;
			int right = size - 1;

			while (left < right) {
				int sum = arr[i] + arr[left] + arr[right];

				if (sum == 0) {
					result.add(Arrays.asList(arr[i], arr[left], arr[right]));
					left++;
					right--;
				} else if (sum < 0)
					left++;
				else
					right--;
			}
		}
		return new ArrayList<>(result);
	}

//	public static List<List<Integer>> threeSum(int[] nums) {
//		List<Integer> positiveNumbers = new ArrayList<Integer>();
//		List<Integer> negativeNumbers = new ArrayList<Integer>();
//		List<Integer> temp;
//
//		int numberOfZeros = 0;
//		int a, b, c = 0;
//
//		for (int i : nums) {
//			if (i < 0) {
//				negativeNumbers.add(i);
//			} else if (i > 0) {
//				positiveNumbers.add(i);
//			} else {
//				numberOfZeros++;
//			}
//		}
//
//		Set<List<Integer>> answer = new HashSet<List<Integer>>();
//		List<List<Integer>> positiveCombinations = getCombinations(positiveNumbers);
//		List<List<Integer>> negativeCombinations = getCombinations(negativeNumbers);
//
//		/*
//		 * This iteration is to check, can any single positive numbers form '0' by sum
//		 * of any negative combinations.
//		 */
//
//		for (int i = 0; i < positiveNumbers.size(); i++) {
//			a = positiveNumbers.get(i);
//
//			for (int j = 0; j < negativeCombinations.size(); j++) {
//				b = negativeCombinations.get(j).get(0);
//				c = negativeCombinations.get(j).get(1);
//				if (a + b + c == 0) {
//					answer.add(new ArrayList<Integer>(Arrays.asList(a, b, c)));
//				}
//			}
//		}
//
//		/*
//		 * This iteration is to check, can any single negative numbers form '0' by sum
//		 * of any positive combinations.
//		 */
//		for (int i = 0; i < negativeNumbers.size(); i++) {
//			a = negativeNumbers.get(i);
//
//			for (int j = 0; j < positiveCombinations.size(); j++) {
//				b = positiveCombinations.get(j).get(0);
//				c = positiveCombinations.get(j).get(1);
//				if (a + b + c == 0) {
//					answer.add(new ArrayList<Integer>(Arrays.asList(a, b, c)));
//				}
//			}
//		}
//
//		/*
//		 * This iteration is to check, can any single positive and negative numbers form
//		 * '0'.
//		 */
//		for (int i = 0; i < nums.length; i++) {
//			a = nums[i];
//
//			for (int j = i + 1; j < nums.length; j++) {
//				b = nums[j];
//
//				if (a + b == 0) {
//					temp = new ArrayList<Integer>(Arrays.asList(a, b, 0));
//					Collections.sort(temp);
//					if (a == 0 && b == 0 && numberOfZeros > 2) {
//						answer.add(temp);
//					} else if ((a != 0 | b != 0) && numberOfZeros != 0) {
//						answer.add(temp);
//					}
//				}
//			}
//		}
//
//		return new ArrayList<List<Integer>>(answer);
//	}
//
//	public static List<List<Integer>> getCombinations(List<Integer> list) {
//		List<List<Integer>> combinations = new ArrayList<List<Integer>>();
//
//		for (int i = 0; i < list.size(); i++) {
//			for (int j = i + 1; j < list.size(); j++) {
//				combinations.add(new ArrayList<Integer>(Arrays.asList(list.get(i), list.get(j))));
//			}
//		}
//
//		return combinations;
//	}

	/* https://leetcode.com/problems/integer-to-roman/ */
	public static String intToRoman(int num) {

		System.out.println(intToRoman(58)); // LVIII
		System.out.println(intToRoman(1695)); // MDCXCV
		System.out.println(intToRoman(2600)); // MMDC
		System.out.println(intToRoman(2400)); // MMCD
		System.out.println(intToRoman(1994)); // MCMXC IV
		System.out.println(intToRoman(3999)); // MMMCMXCIX
		System.out.println(intToRoman(1879)); // MDCCCLXXIX
		System.out.println(intToRoman(3)); // III
		System.out.println(intToRoman(5)); // V
		System.out.println(intToRoman(1)); // I
		System.out.println(intToRoman(10)); // X
		System.out.println(intToRoman(50)); // L

		Map<Integer, String> map = new HashMap<Integer, String>();
		map.put(1, "I");
		map.put(4, "IV");
		map.put(5, "V");
		map.put(9, "IX");
		map.put(10, "X");
		map.put(40, "XL");
		map.put(50, "L");
		map.put(90, "XC");
		map.put(100, "C");
		map.put(400, "CD");
		map.put(500, "D");
		map.put(900, "CM");
		map.put(1000, "M");

		String ans = "";

		while (num >= 1000) {
			ans += "M";
			num -= 1000;
		}

		while (num >= 900) {
			ans += "CM";
			num -= 900;
		}

		while (num >= 500) {
			ans += "D";
			num -= 500;
		}

		while (num >= 400) {
			ans += "CD";
			num -= 400;
		}

		while (num >= 100) {
			ans += "C";
			num -= 100;
		}

		while (num >= 90) {
			ans += "XC";
			num -= 90;
		}

		while (num >= 50) {
			ans += "L";
			num -= 50;
		}

		while (num >= 40) {
			ans += "XL";
			num -= 40;
		}

		while (num >= 10) {
			ans += "X";
			num -= 10;
		}

		while (num >= 9) {
			ans += "IX";
			num -= 9;
		}

		while (num >= 5) {
			ans += "V";
			num -= 5;
		}

		while (num >= 4) {
			ans += "IV";
			num -= 4;
		}

		while (num >= 1) {
			ans += "I";
			num -= 1;
		}

		return ans;

//		String ans = "";
//
//		while (num > 0) {
//
//			if (num >= 1000) {
//				ans += "M";
//				num -= 1000;
//			} else if (num >= 900) {
//				ans += "CM";
//				num -= 900;
//			} else if (num >= 500) {
//				ans += "D";
//				num -= 500;
//			} else if (num >= 400) {
//				ans += "CD";
//				num -= 400;
//			} else if (num >= 100) {
//				ans += "C";
//				num -= 100;
//			} else if (num >= 90) {
//				ans += "XC";
//				num -= 90;
//			} else if (num >= 50) {
//				ans += "L";
//				num -= 50;
//			} else if (num >= 40) {
//				ans += "XL";
//				num -= 40;
//			} else if (num >= 10) {
//				ans += "X";
//				num -= 10;
//			} else if (num >= 9) {
//				ans += "IX";
//				num -= 9;
//			} else if (num >= 5) {
//				ans += "V";
//				num -= 5;
//			} else if (num >= 4) {
//				ans += "IV";
//				num -= 4;
//			} else if (num >= 1) {
//				ans += "I";
//				num -= 1;
//			}
//		}

	}

	/*
	 * https://leetcode.com/problems/find-first-and-last-position-of-element-in-
	 * sorted-array/
	 */
	public static int[] searchRange(int[] nums, int target) {

		searchRange(new int[] { 1, 2 }, 1);// 0 0
		searchRange(new int[] { 2, 1 }, 1);// 1 1
		searchRange(new int[] { 1 }, 1);// 0 0
		searchRange(new int[] { 3, 3, 3, 3 }, 3);// 0 3
		searchRange(new int[] { 3, 3, 3 }, 3);// 0 2
		searchRange(new int[] { 5, 7, 7, 8, 8, 10 }, 8);// 3 4
		searchRange(new int[] { 5, 7, 7, 8, 8, 10 }, 6); // -1 -1

		int[] ans = { -1, -1 };
		int j = 0;

		for (int i = 0; i < nums.length; i++) {
			if (nums[i] == target) {
				ans[j] = i;
				if (j == 0) {
					j++;
				}
			}
		}

		if (ans[0] > -1 && ans[1] == -1) {
			ans[1] = ans[0];
			return ans;
		} else if (ans[0] == -1 && ans[1] > -1) {
			ans[0] = ans[1];
			return ans;
		}

//		System.out.println(ans[0] + ", " + ans[1]);
		return ans;

//		int[] ans = { -1, -1 };
//		int j = 0;
//
//		for (int i = 0; i < nums.length; i++) {
//			if (nums[i] == target) {
//				ans[j] = i;
//				if (j == 0) {
//					j++;
//				}
//			}
//		}
//
//		if (ans[0] > -1 && ans[1] == -1) {
//			ans[1] = ans[0];
//			return ans;
//		} else if (ans[0] == -1 && ans[1] > -1) {
//			ans[0] = ans[1];
//			return ans;
//		}
//
////		System.out.println(ans[0] + ", " + ans[1]);
//		return ans;

//		List<Integer> numsList = new ArrayList<Integer>();
//
//		if (nums.length == 0) {
//			System.out.println("-1 - 1");
//			return new int[] { -1, -1 };
//		}
//
//		for (int i = 0; i < nums.length; i++) {
//			if (nums[i] == target) {
//				numsList.add(i);
//			}
//		}
//
//		if (numsList.isEmpty()) {
//			System.out.println("-1 - 1");
//			return new int[] { -1, -1 };
//		} else {
//			System.out.println(numsList.get(0) + " " + numsList.get(numsList.size() - 1));
//			return new int[] { numsList.get(0), numsList.get(numsList.size() - 1) };

	}

	/* https://leetcode.com/problems/reverse-string/ */
	public static void reverseString(char[] s) {

		reverseString(new char[] { 'h', 'e', 'l', 'l', 'o' }); // olleh
		reverseString(new char[] { 'A', ' ', 'm', 'a', 'n', ',', ' ', 'a', ' ', 'p', 'l', 'a', 'n', ',', ' ', 'a', ' ',
				'c', 'a', 'n', 'a', 'l', ':', ' ', 'P', 'a', 'n', 'a', 'm', 'a' }); // amanaP :lanac a ,nalp a ,nam A
		reverseString(new char[] { 'H', 'a', 'n', 'n', 'a', 'h' }); // hannaH

		char temp1;
		int len = s.length;
		int characterFromLast = len - 1;

		for (int characterFromFront = 0; characterFromFront < len; characterFromFront++, characterFromLast--) {
			if (characterFromFront >= characterFromLast)
				break;

			temp1 = s[characterFromFront];
			s[characterFromFront] = s[characterFromLast];
			s[characterFromLast] = temp1;
		}
	}

	/* https://leetcode.com/problems/remove-element/ */
	public static int removeElement(int[] nums, int val) {

		System.out.println(removeElement(new int[] { 3, 2, 2, 3 }, 3));
		System.out.println(removeElement(new int[] { 0, 1, 2, 2, 3, 0, 4, 2 }, 2));

		int j = 0;

		for (int i = 0; i < nums.length; i++) {
			if (nums[i] != val) {
				nums[j] = nums[i];
				j++;
			}

		}
		return j;
	}

	/* https://leetcode.com/problems/string-to-integer-atoi/ */
	public static int myAtoi(String s) {

		System.out.println(myAtoi("20000000000000000000"));// 1
		System.out.println(myAtoi("+1"));// 1
		System.out.println(myAtoi("   -42"));// -42
		System.out.println(myAtoi(""));// 0
		System.out.println(myAtoi("000     -+41"));// 0
		System.out.println(myAtoi("3.14159"));// 3
		System.out.println(myAtoi(".1"));// 0
		System.out.println(myAtoi("+-12"));// 0
		System.out.println(myAtoi("-91283472332"));// -2147483648
		System.out.println(myAtoi("words and 987"));// 0
		System.out.println(myAtoi("42"));// 42
		System.out.println(myAtoi("4193 with words"));// 4193
		System.out.println(myAtoi("000     -+41"));// 0
		System.out.println(myAtoi("000     --41"));// 0

		int len = s.length();
		int i = 0;
		boolean negatvie = false;
		String temp = "";
		char cc = 0;
		long ans = 0;

		while (i < len && s.charAt(i) == ' ') {
			i++;
		}

		if (i < len && ((s.charAt(i) == '-' || s.charAt(i) == '+'))) {
			if (s.charAt(i) == '-') {
				negatvie = true;
			}
			i++;
		}

		while (i < len && Character.isDigit(s.charAt(i))) {
			cc = s.charAt(i);
			if (Character.isDigit(cc)) {
				temp += cc;
			} else if (!temp.isEmpty()) {
				break;
			}
			if (temp.isEmpty()) {
				return 0;
			}

			if (negatvie) {
				ans = -(Long.valueOf(temp));
			} else {
				ans = Long.valueOf(temp);
			}

			if (ans < -2147483648) {
				return -2147483648;
			} else if (ans > 2147483647) {
				return 2147483647;
			}
			i++;
		}

		return (int) ans;

//		if (s.equals("") || s == null)
//			return 0;
//		int digit = 0;
//		long ans = 0;
//		boolean neg = false;
//		boolean clamp = false;
//		int i = 0;
//
//		while (i < s.length() && s.charAt(i) == ' ') {
//			i++;
//		}
//		
//		
//		if (i < s.length() && (s.charAt(i) == '-' || s.charAt(i) == '+')) {
//			if (s.charAt(i) == '-') {
//				neg = true;
//			}
//			i++;
//
//		}
//
//		while (i < s.length() && Character.isDigit(s.charAt(i))) {
//			digit++;
//			ans = ans * 10 + s.charAt(i) - '0';
//			if (Integer.MAX_VALUE < ans) {
//				clamp = true;
//				break;
//			}
//			i++;
//		}
//
//		if (digit == 0)
//			return 0;
//
//		if (neg) {
//
//			if (clamp)
//				return Integer.MIN_VALUE;
//
//			return -(int) ans;
//		}
//
//		if (clamp) {
//			return Integer.MAX_VALUE;
//		}
//
//		return (int) ans;

//		int len = s.length() - 1;
//		int i = 0;
//		String temp = "";
//		char cc, nc;
//
//		while (i < len) {
//
//			cc = s.charAt(i);
//			nc = s.charAt(i + 1);
//
//			if ((!temp.isEmpty() && !Character.isDigit(cc)) | (temp.isEmpty() && Character.isAlphabetic(cc))) {
//				break;
//			} else if (temp.isEmpty() && (cc == '0' || cc == ' ')) {
//				i++;
//				continue;
//			} else if ((cc == '-' || cc == '+' || Character.isDigit(cc)) && Character.isDigit(nc)) {
//				if (temp.isEmpty()) {
//					temp += cc;
//					temp += nc;
//				} else {
//					temp += nc;
//				}
//			}
//			i++;
//		}
//
//		if (temp.isEmpty())
//			return 0;
//
//		if (Long.valueOf(temp) < -2147483648) {
//			return -2147483648;
//		} else if (Long.valueOf(temp) > 2147483647) {
//			return 2147483647;
//		}
//
//		return Integer.valueOf(temp);
	}

	/*
	 * https://leetcode.com/problems/longest-substring-without-repeating-characters/
	 */
	public static int lengthOfLongestSubstring(String s) {

		System.out.println(lengthOfLongestSubstring(""));// 0
		System.out.println(lengthOfLongestSubstring("dvdf"));// 3
		System.out.println(lengthOfLongestSubstring("dvdfabvdfe"));// 6
		System.out.println(lengthOfLongestSubstring(""));// 0
		System.out.println(lengthOfLongestSubstring("aab"));// 2
		System.out.println(lengthOfLongestSubstring(""));// 0
		System.out.println(lengthOfLongestSubstring(" ")); // 1
		System.out.println(lengthOfLongestSubstring("abcabcbb"));// 3
		System.out.println(lengthOfLongestSubstring("bbbbb"));// 1
		System.out.println(lengthOfLongestSubstring("pwwkew"));// 3

		String[] ss = s.split("");
		Set<String> set = new HashSet<String>();
		int max = 0;
		int subStringStartsAt = 0;
		String cs = "";

		for (int i = 0; i < ss.length; i++) {
			cs = ss[i];
			if (set.isEmpty())
				subStringStartsAt = i;

			if (!set.contains(cs) && !cs.equals("")) {
				set.add(cs);
				max = Math.max(max, set.size());
			} else {
				set.clear();
				i = subStringStartsAt;
				subStringStartsAt = 0;
			}
		}

		return Math.max(max, set.size());

//		Set<Character> set = new HashSet<Character>();
//		int max = 0;
//		int i = 0, j = 0;
//
//		while (i < s.length()) {
//			if (!set.contains(s.charAt(i))) {
//				set.add(s.charAt(i++));
//				max = Math.max(max, set.size());
//			} else {
//				set.remove(s.charAt(j++));
//			}
//		}
//
//		return max;

//		String[] ss = s.split("");
//		Set<String> set = new LinkedHashSet<String>();
//		Set<String> reverseSet = new LinkedHashSet<String>();
//		int max = 0;
//		String cs = "";
//
//		for (int i = 0; i < ss.length; i++) {
//			cs = ss[i];
//			if (!set.contains(cs) && !cs.equals("")) {
//				set.add(cs);
//			} else {
//				max = Math.max(max, set.size());
//				for (int j = i; j >= 0; j--) {
//					if (!reverseSet.contains(ss[j])) {
//						reverseSet.add(ss[j]);
//					} else {
//						
//						reverseSet.clear();
//						set.clear();
//						i = j;
//						break;
//					}
//				}
//			}
//		}
//
//		return Math.max(max, set.size());
	}

	/* https://leetcode.com/problems/power-of-three/ */
	public static boolean isPowerOfThree(int n) {
		System.out.println(isPowerOfThree(30));

//		Set<Integer> set = new TreeSet<Integer>(Arrays.asList(1, 3, 9, 27, 81, 243, 729, 2187, 6561, 19683, 59049,
//				177147, 531441, 1594323, 4782969, 14348907, 43046721, 129140163, 387420489, 1162261467, 2147483647));

//		return new ArrayList<Integer>(Arrays.asList(1, 3, 9, 27, 81, 243, 729, 2187, 6561, 19683, 59049, 177147, 531441,
//				1594323, 4782969, 14348907, 43046721, 129140163, 387420489, 1162261467, 2147483647)).contains(n);

		return n > 0 && 1162261467 % n == 0;

	}

	public static int solution(int[] A) {

		System.out.println(solution(new int[] { 1, 3, 6, 4, 1, 2 }));
		System.out.println(solution(new int[] { 1, 2, 3 }));
		System.out.println(solution(new int[] { -1, -3 }));

		List<Integer> list = new ArrayList<Integer>(Arrays.stream(A).boxed().collect(Collectors.toList()));
		Collections.sort(list);

		int ans = 1;

		while (true) {

			if (!list.contains(ans))
				return ans;

			ans++;
		}
	}

	/* https://leetcode.com/problems/power-of-two/ */
	public static boolean isPowerOfTwo(int n) {

		System.out.println(isPowerOfTwo(-8));

		List<Integer> list = new ArrayList<Integer>();

		for (int i = 0; i < 31; i++) {
			list.add((int) Math.pow(2, i));
		}

		return list.contains(n);
	}

	/*
	 * Write O(n) solution to find largest sum of sub array in a given array with
	 * continuous numbers locations
	 */
	public static int maxSubArray(int[] a) {

		System.out.println(maxSubArray(new int[] { 74, -72, 94, -53, -59, -3, -66, 36, -13, 22, 73, 15, -52, 75 }));
		System.out.println(maxSubArray(new int[] { -2, -3, 2, 4, -1, -2, 1, 5, -3 }));
		System.out.println(maxSubArray(new int[] { 1, 2, 3, 4, 5, 6 }));

		int max = Integer.MIN_VALUE;
		int sum = 0;
		int prevMax = Integer.MIN_VALUE;

		for (int i = 0; i < a.length; i++) {
			sum += a[i];
			max = Math.max(max, sum);
			if (prevMax == max && Integer.signum(max) == -1) {
				sum = 0;
			} else if (max > prevMax) {
				prevMax = max;
			} else if (sum < prevMax && Integer.signum(sum) == -1) {
				sum = 0;
			}
		}

		return max;
	}

	/*
	 * Find the which is minimum distance between two elements when you traverse
	 * from right to left and left to right.
	 */
	public static int minDistance(int[] a, int b, int c) {

		System.out.println(minDistance(new int[] { 0, 1, 2, 3, 10, 11, 2, 1 }, 1, 11));

		int minDistance = Integer.MAX_VALUE;
		int pointA = -1;
		int pointB = -1;

		for (int i = 0; i < a.length; i++) {

			if (pointA == -1 && a[i] == b) {
				pointA = i;
			}

			if (pointB == -1 && a[i] == c) {
				pointB = i;
			}

			if (pointA > -1 && pointB > -1) {
				minDistance = Math.min(minDistance, Math.abs(pointA - pointB));
				pointA = -1;
			}
		}

		return minDistance;
	}

	/* https://leetcode.com/problems/roman-to-integer/ */
	public static int romanToInt(String s) {

		System.out.println(romanToInt("LVIII")); // 58
		System.out.println(romanToInt("MDCXCV")); // 1695
		System.out.println(romanToInt("MMDC")); // 2600
		System.out.println(romanToInt("MMCD")); // 2400
		System.out.println(romanToInt("MCMXCIV")); // 1994
		System.out.println(romanToInt("MMMCMXCIX")); // 3999
		System.out.println(romanToInt("MDCCCLXXIX")); // 1879
		System.out.println(romanToInt("III")); // 3
		System.out.println(romanToInt("V")); // 5
		System.out.println(romanToInt("I")); // 1
		System.out.println(romanToInt("X")); // 10
		System.out.println(romanToInt("L")); // 50

		Map<Character, Integer> map = new HashMap<Character, Integer>();
		map.put('I', 1);
		map.put('V', 5);
		map.put('X', 10);
		map.put('L', 50);
		map.put('C', 100);
		map.put('D', 500);
		map.put('M', 1000);

		if (s.length() == 1)
			return map.get(s.charAt(0));

		int ans = 0;
		int len = s.length();
		int c1;
		int c2;

		for (int i = 0; i < len - 1; i++) {
			c1 = map.get(s.charAt(i));
			c2 = map.get(s.charAt(i + 1));

			if (c1 >= c2) {
				ans += c1;
			} else {
				ans += c2 - c1;
				i++;
			}

			if (i + 2 == len) {
				ans += map.get(s.charAt(i + 1));
			}
		}
		return ans;
	}

	/*
	 * Given an array of integers nums and an integer target, return indices of the
	 * two numbers such that they add up to target.
	 */
	public static int[] twoSum(int[] nums, int target) {

		twoSum(new int[] { -1, -2, -3, -4, -5 }, -8);// 2 4
		twoSum(new int[] { 11, 3, 5, 15, 1, 2, 7 }, 9);// 5 6
		twoSum(new int[] { 0, 4, 3, 0 }, 0); // 0,3
		twoSum(new int[] { -3, 4, 3, 90 }, 0); // 0,2
		twoSum(new int[] { 3, 3 }, 5); // empty
		twoSum(new int[] { 3, 3 }, 6);// 0 1
		twoSum(new int[] { 2, 7, 11, 15 }, 9); // 0 1
		twoSum(new int[] { 3, 2, 4 }, 6);// 1 2

		int[] result = new int[2];
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (int i = 0; i < nums.length; i++) {
			if (map.containsKey(target - nums[i])) {
				result[1] = i;
				result[0] = map.get(target - nums[i]);
				System.out.println(result[0] + " & " + result[1]);
				return result;
			}
			map.put(nums[i], i);
		}
		return result;
	}

	/* https://leetcode.com/problems/happy-number/ */
	public static boolean isHappy(int n) {
		/*
		 * If (n >1 && n < 10) return false.
		 * 
		 * Loop1 to calculate the sum of the squares of its digits
		 * 
		 * Condition to check sum of square of digits equals to 1 or 7
		 */

		System.out.println(isHappy(2));
		System.out.println(isHappy(100));

		int sum = 0;
		while (true) {

			while (n != 0) {
				sum += Math.pow(n % 10, 2);
				n = n / 10;
			}

			if (sum == 1 || sum == 7)
				return true;
			if ((sum > 1 && sum < 7) || sum == 9)
				return false;

			n = sum;
			sum = 0;
		}
	}

	/* https://leetcode.com/problems/median-of-two-sorted-arrays/ */

	public static double findMedianSortedArrays(int[] nums1, int[] nums2) {

		System.out.println(findMedianSortedArrays(new int[] { 1, 2 }, new int[] { 3, 4 }));
		System.out.println(findMedianSortedArrays(new int[] { 1, 2 }, new int[] { 3 }));

		System.out
				.println(findMedianSortedArrays(new int[] { -200, -100, -5, -3, -1, -300 }, new int[] { 1, 2, 3, 4 }));

		int m = nums1.length;
		int n = nums2.length;
		int l = m + n;
		int j = 0;
		double median;

		int[] a = new int[l];

		for (int i : nums1) {
			a[j++] = i;
		}

		for (int i : nums2) {
			a[j++] = i;
		}

		Arrays.sort(a);

		if ((l) % 2 == 0) {
			median = (double) ((a[(l / 2) - 1]) + (a[l / 2])) / 2;
		} else {
			median = a[l / 2];
		}

		return median;
	}

	/*
	 * https://leetcode.com/problems/longest-common-prefix//
	 */
	public static String longestCommonPrefix(String[] strs) {

		System.out.println(longestCommonPrefix(new String[] { "", "" }));
		System.out.println(longestCommonPrefix(new String[] { "a" }));
		System.out.println(longestCommonPrefix(new String[] { "flower", "flow", "flight" }));
		System.out.println(longestCommonPrefix(new String[] { "dog", "racecar", "car" }));

		/*
		 * Find the smallest String
		 * 
		 * Loop1 to iterate over the characters - use smallest string length
		 * 
		 * Loop2 to iterate over all strings in array
		 * 
		 * Have a boolean condition to check s.charAt(i) exists in all strings.
		 * 
		 * If boolean is true then add it to temp else break the outer loop (loop1) and
		 * return the temp.
		 */

		int minLen = Integer.MAX_VALUE;
		String temp = "";
		String cs = "";

		if (strs.length == 1)
			return strs[0];

		for (String s : strs) {
			minLen = Math.min(minLen, s.length());
		}

		outer: for (int i = 0; i < minLen; i++) {
			for (int j = 0; j < strs.length - 1; j++) {
				cs = strs[j];
				if (cs.charAt(i) != strs[j + 1].charAt(i)) {
					break outer;
				}
			}
			temp = temp + cs.charAt(i);
		}
		return temp;
	}

	static /* https://leetcode.com/problems/single-number/ */
	int single = -1;

	public static int singleNumber(int[] nums) {

		System.out.println(singleNumber(new int[] { 4, 1, 2, 1, 2 }));
		System.out.println(singleNumber(new int[] { 1, 2, 4, 1, 2 }));
		System.out.println(singleNumber(new int[] { 2, 2, 1 }));
		System.out.println(singleNumber(new int[] { -2, -2, 1 }));
		System.out.println(singleNumber(new int[] { 1 }));
		System.out.println(singleNumber(new int[] {}));

		HashSet<Integer> set = new HashSet<Integer>();

		for (int i : nums) {
			if (!set.contains(i)) {
				set.add(i);
			} else {
				set.remove(i);
			}
		}

		set.forEach(a -> single = a);

		return single;
	}

	/*
	 * https://leetcode.com/problems/find-common-characters/
	 */
	public static List<String> commonChars(String[] words) {

		System.out.println(commonChars(new String[] { "acabcddd", "bcbdbcbd", "baddbadb", "cbdddcac", "aacbcccd",
				"ccccddda", "cababaab", "addcaccd" }));
		System.out.println(commonChars(new String[] { "cool", "lock", "cook" }));
		System.out.println(commonChars(new String[] { "bella", "labele", "roller" }));
//
//		if (words.length == 1)
//			return new ArrayList<String>(Arrays.asList(words[0].split("")));
//
//		List<String> commonCharacters = new ArrayList<String>();
//		String[] lettersInWord;
//		boolean characterExistsInAllWords = true;
//		String nextWord = null;
//		String cc;
//
//		lettersInWord = words[0].split("");
//		for (int i = 0; i < lettersInWord.length; i++) {
//			characterExistsInAllWords = true;
//			cc = lettersInWord[i];
//			outer: for (int j = 1; j < words.length; j++) {
//				nextWord = words[j];
//				if (!nextWord.contains(cc)) {
//					characterExistsInAllWords = false;
//					break outer;
//				}
//				words[j] = nextWord.replaceFirst(cc, "");
//			}
//			if (characterExistsInAllWords) {
//				commonCharacters.add(cc);
//			}
//		}
//		return commonCharacters;

		Map<String, Integer> map = new HashMap<String, Integer>();
		Map<String, Integer> temp = new HashMap<String, Integer>();
		Set<String> set = new HashSet<String>();
		List<String> commonCharacters = new ArrayList<String>();

		if (words.length == 1)
			return new ArrayList<String>(Arrays.asList(words[0].split("")));

		for (int j = 0; j < words.length; j++) {
			String[] sa = words[j].split("");
			for (String s : sa) {
				if (set.contains(s))
					continue;
				temp.put(s, temp.getOrDefault(s, 0) + 1);
			}
			if (map.isEmpty()) {
				map.putAll(temp);
				temp.clear();
			} else {
				map.forEach((k, v) -> {
					if (temp.containsKey(k) && temp.get(k) < v) {
						map.put(k, temp.get(k));
					} else if (temp.containsKey(k)) {
						map.put(k, v);
					} else {
						set.add(k);
					}
				});
				temp.clear();
			}
		}

		map.forEach((k, v) -> {
			if (!set.contains(k)) {
				while (v > 0) {
					commonCharacters.add(k);
					v--;
				}
			}
		});
		return commonCharacters;
	}

	/*
	 * https://leetcode.com/problems/make-array-zero-by-subtracting-equal-amounts/
	 */
	public static int minimumOperations(int[] nums) {
		System.out.println(minimumOperations(new int[] { 1, 5, 0, 3, 5 }));
		System.out.println(minimumOperations(new int[] { 0 }));

		Set<Integer> set = new HashSet<>();

		for (int a : nums)
			if (a > 0)
				set.add(a);
		return set.size();
	}

	/*
	 * https://leetcode.com/problems/longest-palindromic-substring/
	 */
	public static String longestPalindrome(String s) {

		System.out.println(longestPalindrome(
				"zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz"));
//
		System.out.println(longestPalindrome(
				"mwwfjysbkebpdjyabcfkgprtxpwvhglddhmvaprcvrnuxifcrjpdgnktvmggmguiiquibmtviwjsqwtchkqgxqwljouunurcdtoeygdqmijdympcamawnlzsxucbpqtuwkjfqnzvvvigifyvymfhtppqamlgjozvebygkxawcbwtouaankxsjrteeijpuzbsfsjwxejtfrancoekxgfyangvzjkdskhssdjvkvdskjtiybqgsmpxmghvvicmjxqtxdowkjhmlnfcpbtwvtmjhnzntxyfxyinmqzivxkwigkondghzmbioelmepgfttczskvqfejfiibxjcuyevvpawybcvvxtxycrfbcnpvkzryrqujqaqhoagdmofgdcbhvlwgwmsmhomknbanvntspvvhvccedzzngdywuccxrnzbtchisdwsrfdqpcwknwqvalczznilujdrlevncdsyuhnpmheukottewtkuzhookcsvctsqwwdvfjxifpfsqxpmpwospndozcdbfhselfdltmpujlnhfzjcgnbgprvopxklmlgrlbldzpnkhvhkybpgtzipzotrgzkdrqntnuaqyaplcybqyvidwcfcuxinchretgvfaepmgilbrtxgqoddzyjmmupkjqcypdpfhpkhitfegickfszermqhkwmffdizeoprmnlzbjcwfnqyvmhtdekmfhqwaftlyydirjnojbrieutjhymfpflsfemkqsoewbojwluqdckmzixwxufrdpqnwvwpbavosnvjqxqbosctttxvsbmqpnolfmapywtpfaotzmyjwnd"));
		// khvhk
		System.out.println(longestPalindrome("a121")); // 121
		System.out.println(longestPalindrome("a")); // a
		System.out.println(longestPalindrome("babab")); // babab
		System.out.println(longestPalindrome("ac")); // a
		System.out.println(longestPalindrome("bb")); // bb
		System.out.println(longestPalindrome("babad")); // bab or aba
		System.out.println(longestPalindrome("abb")); // bb
		System.out.println(longestPalindrome("bb")); // bb
		System.out.println(longestPalindrome("cbbd")); // bb

		int length = s.length();

		if (length == 1)
			return s;

		if (new HashSet<String>(Arrays.asList(s.split(""))).size() == 1)
			return s;

		String longestPallindrome = "";
		String temp = "";

		for (int i = 0; i < length; i++) {
			for (int j = i + 1; j < length; j++) {
				if (Math.subtractExact(j, i) < temp.length())
					continue;
				temp = isPallindrome(s, i, j);
				if (temp.length() > longestPallindrome.length()) {
					longestPallindrome = temp;
				}
			}
		}
		return longestPallindrome;
	}

	public static String isPallindrome(String s, int i, int j) {
		int start = i, end = j;
		while (i < j) {
			if (s.charAt(i) == s.charAt(j)) {
				i++;
				j--;
			} else {
				return s.substring(0, 1);
			}
		}
		return s.substring(start, end + 1);
	}

//	/*
//	 * https://leetcode.com/problems/longest-palindromic-substring/
//	 */
//	public static String longestPalindrome(String s) {
//
//		String[] letters = s.split("");
//		int length = letters.length;
//		String longestPalindrome = "";
//		String c = "", temp = "";
//		StringBuilder sb = new StringBuilder();
//
//		for (int i = 0; i < length; i++) {
//			c = letters[i];
//			sb.append(c);
//			for (int j = i + 1; j < length; j++) {
//				sb = sb.append(letters[j]);
//				temp = sb.toString();
//				if (temp.equals(sb.reverse().toString()) && temp.length() > longestPalindrome.length()) {
//					longestPalindrome = sb.toString();
//				}
//				sb.reverse();
//			}
//			c = "";
//			temp = "";
//			sb.setLength(0);
//		}
//
//		if (longestPalindrome.isEmpty()) {
//			return letters[0];
//		}
//		return longestPalindrome;
//	}

	/* https://leetcode.com/problems/fair-distribution-of-cookies/ */

	public static int distributeCookies(int[] cookies, int k) {
		int minUnfairness = Integer.MAX_VALUE;

		System.out.println(distributeCookies(new int[] { 30, 16, 15 }, 2));

		int[] children = new int[k];
		rec(cookies, 0, k, children);
		return minUnfairness;
	}

	public static void rec(int[] cookies, int cookie, int k, int[] children) {
		int minUnfairness = Integer.MAX_VALUE;

		if (cookie == cookies.length) {
			int max = 0;
			for (int c : children)
				max = Math.max(max, c);
			minUnfairness = Math.min(minUnfairness, max);
			return;
		}
		for (int i = 0; i < k; i++) {
			children[i] += cookies[cookie];
			rec(cookies, cookie + 1, k, children);
			children[i] -= cookies[cookie];
		}
	}

	/* https://leetcode.com/problems/optimal-partition-of-string/ */
	public static int partitionString(String s) {

		System.out.println(partitionString("abacaba"));// 4- ab a ca ba
		System.out.println(partitionString(
				"vyvrmhfbawyabanxadvlzllpwnanjxyjhhzzjokcszjeooitnvadkuzsnklxriworikarhjmcqvajvkokszbmhxacgztnpcylb"));
		// 19

		int ans = 1;
		int length = s.length();
		Set<Character> set = new HashSet<Character>();
		char cc;

		for (int i = 0; i < length; i++) {
			cc = s.charAt(i);
			if (!set.contains(cc)) {
				set.add(cc);
			} else {
				set.clear();
				ans++;
				set.add(cc);
			}
		}

		return ans;
	}

	/* https://leetcode.com/problems/reformat-phone-number/ */
	public static String reformatNumber(String number) {

		System.out.println(reformatNumber("22-"));
		System.out.println(reformatNumber("9964-"));
		System.out.println(reformatNumber("1-23-45 6"));
		System.out.println(reformatNumber("123 4-567"));
		System.out.println(reformatNumber("123 4-5678812"));

		number = number.replaceAll("[- ]", "");
		int length = number.length();
		String ans = "", temp = "";

		while (length > 0) {

			if (length % 3 != 0 && length < 5) {
				temp = number.substring(0, 2);
				number = number.substring(2);
				length -= 2;
				ans = length == 0 ? ans + temp : ans + temp + "-";
			}

			if (length >= 3) {
				temp = number.substring(0, 3);
				number = number.substring(3);
				length -= 3;
				ans = length == 0 ? ans + temp : ans + temp + "-";
			}
		}
		return ans;
	}

	/* https://leetcode.com/problems/calculate-money-in-leetcode-bank/ */
	public static int totalMoney(int n) {

		System.out.println(totalMoney(20));

		int sum = 0, weekDay = 1, totalDays = 1, investment = 1, increment = 1;

		while (totalDays <= n) {

			if (weekDay == 8) {
				sum += ++increment;
				investment = increment + 1;
				weekDay = 1;
			} else {
				sum += investment++;
			}
			weekDay++;
			totalDays++;
		}
		return sum;
	}

	/*
	 * https://leetcode.com/problems/number-of-rectangles-that-can-form-the-largest-
	 * square/
	 */
	public static int countGoodRectangles(int[][] rectangles) {

		System.out.println(countGoodRectangles(new int[][] { { 2, 3 }, { 3, 7 }, { 4, 3 }, { 3, 7 } }));// 3
		System.out.println(countGoodRectangles(new int[][] { { 5, 8 }, { 3, 9 }, { 5, 12 }, { 16, 5 } }));// 3

		int min, max = 0, previousMax = 0, highesht = 0;

		for (int j[] : rectangles) {
			min = Math.min(j[0], j[1]);
			previousMax = max;
			max = Math.max(max, min);
			highesht = (max == min && previousMax == max) ? highesht + 1
					: (previousMax < max) ? highesht = 1 : highesht;
		}

		return highesht;
//		int max = 0, ans =0;

//		int i = 0,  min;
//		int[] squares = new int[rectangles.length];
//
//		for (int j[] : rectangles) {
//			min = Math.min(j[0], j[1]);
//			max = Math.max(max, min);
//			squares[i++] = min;
//		}
//		
//		Arrays.stream(squares).forEach( a ->{
//			ans = a == max? ans+1: ans+0;
//		});
//		
//		return ans;
	}

	/* https://leetcode.com/problems/find-the-highest-altitude/ */
	public static int largestAltitude(int[] gain) {

		System.out.println(largestAltitude(new int[] { -4, -3, -2, -1, 4, 3, 2 }));
		System.out.println(largestAltitude(new int[] { 52, -91, 72 }));
		System.out.println(largestAltitude(new int[] { -5, 1, 5, 0, -7 }));

		int highesht = 0, temp = 0;

		for (int i = 0; i < gain.length; i++) {
			temp += gain[i];
			highesht = Math.max(highesht, temp);
		}
		return highesht;
	}

	/* https://leetcode.com/problems/latest-time-by-replacing-hidden-digits/ */
	public static String maximumTime(String time) {

		System.out.println(maximumTime("2?:?0"));
		System.out.println(maximumTime("0?:3?"));
		System.out.println(maximumTime("?2:3?"));
		System.out.println(maximumTime("??:??"));
		System.out.println(maximumTime("1?:22"));
		System.out.println(maximumTime("??:??"));

		char[] timeArr = time.toCharArray();

		timeArr[0] = (timeArr[0] == '?' && timeArr[1] == '?') ? '2'
				: (timeArr[0] == '?' && timeArr[1] != '?') ? (timeArr[1] < '4' ? '2' : '1') : timeArr[0];
		timeArr[1] = (timeArr[0] == '?' && timeArr[1] == '?') ? '3'
				: (timeArr[0] != '?' && timeArr[1] == '?') ? (timeArr[0] < '2' ? '9' : '3') : timeArr[1];
		timeArr[3] = (timeArr[3] == '?') ? '5' : timeArr[3];
		timeArr[4] = (timeArr[4] == '?') ? '9' : timeArr[4];

		return String.valueOf(timeArr);
	}

	/* https://leetcode.com/problems/maximum-number-of-balls-in-a-box/ */
	public static int countBalls(int lowLimit, int highLimit) {
		System.out.println(countBalls(19, 28));

		int boxNumber = 0, answer = 0, num = 0;

		Map<Integer, Integer> map = new TreeMap<Integer, Integer>();
		for (int i = lowLimit; i <= highLimit; i++) {
			boxNumber++;
			num = i;
			if (i == lowLimit || i % 10 == 0) {
				boxNumber = 0;
				while (num != 0) {
					boxNumber += (num % 10);
					num /= 10;
				}
			}
			map.put(boxNumber, map.getOrDefault(boxNumber, 0) + 1);
			answer = Math.max(answer, map.get(boxNumber));
		}

		return answer;
	}

	/*
	 * https://leetcode.com/problems/minimum-changes-to-make-alternating-binary-
	 * string/
	 */
	public static int minOperations(String s) {

		System.out.println(minOperations("10010100")); // 3
		System.out.println(minOperations("0110")); // 2
		System.out.println(minOperations("0100")); // 1
		System.out.println(minOperations("10")); // 0
		System.out.println(minOperations("1111")); // 2
		System.out.println(minOperations("0111")); // 1

//		int length = s.length();
//		int i = 0, count = 0, count2 = 0, r = 0;
//		char intialPosition = s.charAt(0) == '0' ? '0' : '1';
//		char nextPosition = intialPosition == '0' ? '1' : '0';
//		String s2 = nextPosition + s.substring(1);
//		char cc, cc2;
//
//		while (i < length) {
//			cc = s.charAt(i);
//			r = i % 2;
//			if (r == 0 && cc != intialPosition) {
//				count++;
//			} else if (r == 1 && cc != nextPosition) {
//				count++;
//			}
//
//			cc2 = s2.charAt(i);
//			if (r == 0 && cc2 != nextPosition) {
//				count2++;
//			} else if (r == 1 && cc2 != intialPosition) {
//				count2++;
//			}
//			i++;
//		}
//		return Math.min(count, count2 + 1);

//		int length = s.length();
//		int i = 0, count = 0, count2 = 0, r = 0;
//		char intialPosition = s.charAt(0) == '0' ? '0' : '1';
//		char nextPosition = intialPosition == '0' ? '1' : '0';
//		String s2 = nextPosition + s.substring(1);
//		char cc, cc2;
//
//		while (i < length) {
//			cc = s.charAt(i);
//			cc2 = s2.charAt(i);
//			r = i % 2;
//			count = ((r == 0 && cc != intialPosition) || (r == 1 && cc != nextPosition)) ? count + 1 : count + 0;
//			count2 = ((r == 0 && cc2 != nextPosition) || (r == 1 && cc2 != intialPosition)) ? count2 + 1 : count2 + 0;
//			i++;
//		}
//		return Math.min(count, count2 + 1);

		int length = s.length();
		int i = 0, count = 0, r = 0;
		char intialPosition = s.charAt(0) == '0' ? '0' : '1';
		char nextPosition = intialPosition == '0' ? '1' : '0';
		char cc;

		while (i < length) {
			cc = s.charAt(i);
			r = i % 2;
			count = ((r == 0 && cc != intialPosition) || (r == 1 && cc != nextPosition)) ? count + 1 : count + 0;
			i++;
		}
		return Math.min(count, length - count);

	}

	/* https://leetcode.com/problems/merge-strings-alternately/ */
	public static String mergeAlternately(String word1, String word2) {

		System.out.println(mergeAlternately("ab", "pqrs"));
		System.out.println(mergeAlternately("pqrs", "ab"));
		System.out.println(mergeAlternately("abcd", "pqrs"));

//		int i = 0, j = 0;
//		int word1Length = word1.length();
//		int word2Length = word2.length();
//		int minLength = word1Length > word2Length ? word2Length : word1Length;
//		char[] ans = new char[word1Length + word2Length];
//
//		while (i < word1Length || i < word2Length) {
//			if (i < minLength) {
//				ans[j++] = word1.charAt(i);
//				ans[j++] = word2.charAt(i);
//			} else if (i < word1Length) {
//				ans[j++] = word1.charAt(i);
//			} else if (i < word2Length) {
//				ans[j++] = word2.charAt(i);
//			}
//			i++;
//		}
//		return String.valueOf(ans);

		int i = 0, j = 0;
		int word1Length = word1.length();
		int word2Length = word2.length();
		char[] ans = new char[word1Length + word2Length];

		while (i < word1Length || i < word2Length) {
			if (i < word1Length) {
				ans[j++] = word1.charAt(i);
			}
			if (i < word2Length) {
				ans[j++] = word2.charAt(i);
			}
			i++;
		}
		return String.valueOf(ans);
	}

	public static int[][] floodFill(int[][] image, int sr, int sc, int newColor) {
		floodFill(new int[][] { { 1, 1, 1 }, { 1, 1, 0 }, { 1, 0, 1 } }, 1, 1, 2);

		if (image[sr][sc] == newColor)
			return image;
		fill(image, sr, sc, image[sr][sc], newColor);
		return image;
	}

	private static void fill(int[][] image, int sr, int sc, int color, int newColor) {
		if (sr < 0 || sr >= image.length || sc < 0 || sc >= image[0].length || image[sr][sc] != color)
			return;
		image[sr][sc] = newColor;
		fill(image, sr + 1, sc, color, newColor);
		fill(image, sr - 1, sc, color, newColor);
		fill(image, sr, sc + 1, color, newColor);
		fill(image, sr, sc - 1, color, newColor);
	}

	/* https://leetcode.com/problems/count-items-matching-a-rule/ */
	public static int countMatches(List<List<String>> items, String ruleKey, String ruleValue) {

		List<List<String>> list = new ArrayList<List<String>>();
		list.add(new ArrayList<String>(Arrays.asList("phone", "blue", "pixel")));
		list.add(new ArrayList<String>(Arrays.asList("computer", "silver", "phone")));
		list.add(new ArrayList<String>(Arrays.asList("phone", "gold", "iphone")));

		System.out.println(countMatches(list, "type", "phone"));

		int ans = 0;
//		for (int i = 0; i < items.size(); i++) {
//			if (ruleKey.equals("type")) {
//				if (items.get(i).get(0).equals(ruleValue))
//					ans++;
//			} else if (ruleKey.equals("color")) {
//				if (items.get(i).get(1).equals(ruleValue))
//					ans++;
//			} else if (ruleKey.equals("name")) {
//				if (items.get(i).get(2).equals(ruleValue))
//					ans++;
//			}
//		}

//		if (ruleKey.equals("type")) {
//			for (int i = 0; i < items.size(); i++) {
//				if (items.get(i).get(0).equals(ruleValue))
//					ans++;
//			}
//		} else if (ruleKey.equals("color")) {
//			for (int i = 0; i < items.size(); i++) {
//				if (items.get(i).get(1).equals(ruleValue))
//					ans++;
//			}
//		} else if (ruleKey.equals("name")) {
//			for (int i = 0; i < items.size(); i++) {
//				if (items.get(i).get(2).equals(ruleValue))
//					ans++;
//			}
//
//		}

		int ruleKeyVal = 0;

		switch (ruleKey) {

		case "type":
			ruleKeyVal = 0;
			break;

		case "color":
			ruleKeyVal = 1;
			break;

		case "name":
			ruleKeyVal = 2;
			break;
		}

		for (int i = 0; i < items.size(); i++) {
			if (items.get(i).get(ruleKeyVal).equals(ruleValue))
				ans++;
		}

		return ans;
	}

	public static int sumOfUnique(int[] nums) {

		System.out.println(sumOfUnique(new int[] { 1, 1, 1, 1, 1 }));

//		static int sum;

//		Map<Integer, Integer> map = new TreeMap<Integer, Integer>();
//
//		for (int i : nums) {
//			map.put(i, map.getOrDefault(i, 0) + 1);
//		}
//
//		map.forEach((k, v) -> {
//			if (v == 1) {
//				sum += k;
//			}
//		});
//		return sum;
		int sum = 0;
		int[] counter = new int[101];

		for (int i : nums) {
			counter[i]++;

			if (counter[i] == 1)
				sum += i;

			if (counter[i] == 2)
				sum -= i;

		}
		return sum;
	}

	/* https://leetcode.com/problems/word-pattern/ */
	public static boolean wordPattern(String pattern, String s) {

		System.out.println(wordPattern("abba", "dog dog dog dog")); // false
		System.out.println(wordPattern("abba", "dog cat cat dog")); // true
		System.out.println(wordPattern("abba", "dog cat cat fish")); // false
		System.out.println(wordPattern("aaaa", "dog cat cat dog")); // false

		Map<Character, String> kv = new TreeMap<Character, String>();
		String[] words = s.split(" ");
		String w;
		Character c;

		if (words.length != pattern.length()) {
			return false;
		}

		for (int i = 0; i < pattern.length(); i++) {
			c = pattern.charAt(i);
			w = words[i];
			if (!kv.containsKey(c)) {
				if (kv.containsValue(w)) {
					return false;
				}
				kv.put(c, w);
			} else if (!kv.get(c).equals(w)) {
				return false;
			}
		}
		return true;
	}

	/* https://leetcode.com/problems/missing-number/ */
	public static int missingNumber(int[] nums) {

//			System.out.println(missingNumber(new int[] { 9, 6, 4, 2, 3, 5, 7, 0, 1 }));
		System.out.println(missingNumber(new int[] { 3, 0, 1 }));
//			System.out.println(missingNumber(new int[] { 0, 1 }));

		Arrays.sort(nums);
		int j = -1;

		for (int i : nums)
			if (i != ++j)
				return j;

		return j + 1;

//		int count = (nums.length + 1) * nums.length / 2;
//		for (int num : nums)
//			count -= num;
//		return count;

	}

	/* https://leetcode.com/problems/move-zeroes/ */
	public static void moveZeroes(int[] nums) {
		moveZeroes(new int[] { 0, 1, 0, 3, 12 });

		int k = 0;

		for (int i : nums) {
			if (i != 0) {
				nums[k++] = i;
			}
		}

		while (k < nums.length) {
			nums[k++] = 0;
		}
	}

	/* https://leetcode.com/problems/find-greatest-common-divisor-of-array/ */
	public static int findGCD(int[] nums) {

//		System.out.println(findGCD(new int[] {2,5,6,9,10})); //2
		System.out.println(findGCD(new int[] { 6, 9, 10 })); // 2
//		System.out.println(findGCD(new int[] {3,3})); //3
//		System.out.println(findGCD(new int[] {8,5,8,7,4})); //4

		List<Integer> list = new ArrayList<Integer>(Arrays.stream(nums).boxed().collect(Collectors.toList()));

		int min = Collections.min(list);
		int max = Collections.max(list);

		for (int i = min; i > 1; i--) {
			if (min % i == 0 && max % i == 0) {
				return i;
			}
		}
		return 1;

	}

	/* https://leetcode.com/problems/excel-sheet-column-title/ */
	public static String convertToTitle(int columnNumber) {

		System.out.println(convertToTitle(931));

		StringBuilder sb = new StringBuilder();

		while (columnNumber > 0) {
			--columnNumber;
			sb.append((char) (columnNumber % 26 + 'A'));
			columnNumber = columnNumber / 26;
		}

		return sb.reverse().toString();
	}

	public static String cn(int columnNumber) {
		char a = (char) ((columnNumber / 26) + 64);
		char b = (char) ((columnNumber % 26) + 64);
		return a + "" + b + "";
	}

	/* SN */
	public static boolean returnPythogersNumber(int[] arr, int n) {

		// returnPythogersNumber(new int[] { 10, 4, 6, 12, 5 }, 5);

		if (n < 3)
			return false;

		List<Integer> list = new ArrayList<Integer>(Arrays.stream(arr).boxed().collect(Collectors.toList()));
		Collections.sort(list);
		int a = -1, b = -1, c = -1;

		for (int i = 1; i < n; i++) {

			if (list.get(i) - 1 == list.get(i - 1)) {
				a = list.get(i - 1);
				b = list.get(i);
			}

			if ((a > -1 && b > -1) && i < (n - 1) && list.get(i) == list.get(i + 1) - 1) {
				c = list.get(i + 1);
				if ((a * a + b * b) == c * c)
					return true;
			}
		}

		return false;
	}

	/*
	 * https://leetcode.com/problems/number-of-students-doing-homework-at-a-given-
	 * time/
	 */
	public static int busyStudent(int[] startTime, int[] endTime, int queryTime) {

		System.out.println(busyStudent(new int[] { 1, 2, 3 }, new int[] { 3, 2, 7 }, 4));
		System.out.println(busyStudent(new int[] { 9, 8, 7, 6, 5, 4, 3, 2, 1 },
				new int[] { 10, 10, 10, 10, 10, 10, 10, 10, 10 }, 5)); // 5

//		int s = 0;
//
//		for (int i = 0; i < endTime.length; i++) {
//			if (startTime[i] <= queryTime && queryTime <= endTime[i])
//				s++;
//		}
//
//		return s;

		int s = 0;

		for (int i = 0; i < endTime.length; i++) {
			if (startTime[i] <= queryTime && queryTime <= endTime[i])
				s++;
		}

		return s;
	}

	/* https://leetcode.com/problems/count-of-matches-in-tournament/ */
	public static int numberOfMatches(int n) {
		System.out.println(numberOfMatches(14));

		int a = 0, q = 0;

		while (n != 1) {
			q = n / 2;
			a += q;
			n = n - (q);
		}
		return a;
	}

	/* https://leetcode.com/problems/number-of-students-unable-to-eat-lunch/ */
	public static int countStudents(int[] students, int[] sandwiches) {
		// System.out.println(countStudents(new int[] { 1, 1, 1, 1, 0, 0, 1 }, new int[]
		// { 0, 0, 0, 1, 1, 1, 1 }));

		int count[] = { 0, 0 }, n = students.length, k;
		for (int a : students)
			count[a]++;
		for (k = 0; k < n && count[sandwiches[k]] > 0; ++k)
			count[sandwiches[k]]--;
		return n - k;
	}

	/* https://leetcode.com/problems/sign-of-the-product-of-an-array/ */
	public static int arraySign(int[] nums) {
//		System.out.println(arraySign(new int[] { -1, -2, -3, 0,4, 3, 2, 1 }));

		int negativeNumbers = 0;

		for (int i : nums) {
			if (i == 0)
				return 0;

			if (i < 0)
				negativeNumbers++;

		}
		return (negativeNumbers % 2 == 1) ? -1 : 1;
	}

	/* https://leetcode.com/problems/number-of-different-integers-in-a-string/ */
	public static int numDifferentIntegers(String word) {

		System.out.println(numDifferentIntegers("a123bc34d8ef34")); // 3
		System.out.println(numDifferentIntegers("leet1234code234")); // 2
		System.out.println(numDifferentIntegers("167278959591294")); // 1
		System.out.println(numDifferentIntegers("a1b01c001")); // 1
		System.out.println(numDifferentIntegers("gi851a851q8510v")); // 2
		System.out.println(numDifferentIntegers("0a0")); // 1

		Set<String> set = new HashSet<String>();
		String temp = "";
		char presentLetter;
		int length = word.length();

		for (int i = 0; i < length; i++) {
			presentLetter = word.charAt(i);
			if (Character.isDigit(presentLetter)) {
				if ((temp == "" && presentLetter != '0') | temp != "") {
					temp += word.charAt(i);
				} else if (presentLetter == '0' && i < length) {

				}
			}

			if ((!temp.equals("") && !Character.isDigit(presentLetter))
					| (!temp.equals("") && i == word.length() - 1)) {
				set.add(temp);
				temp = "";
			}
		}
		return set.size();

//		Set<String> set = new HashSet<String>();
//		String[] numbers = word.replaceAll("[a-z]", ",").split(",");
//		String temp = "";
//
//		for (int i = 0; i < numbers.length; i++) {
//			temp = numbers[i];
//			if (!temp.contains(" ") && !temp.isEmpty())
//				set.add(temp.replaceFirst("^0+", ""));
//		}
//		return set.size();
	}

	/* https://leetcode.com/problems/sum-of-digits-in-base-k/ */
	public static int sumBase(int n, int k) {

		// System.out.println(sumBase(199, 6));

		int result = 0;
		while (n != 0) {
			result += n % k;
			n /= k;
		}
		return result;
	}

	/* https://leetcode.com/problems/sum-of-digits-of-string-after-convert/ */
	public static int getLucky(String s, int k) {

		// System.out.println(getLucky("leetcode", 2));

//		String value = "";
//		int sum = 0;
//
//		for (int i = 0; i < s.length(); i++) {
//			value += Character.getNumericValue(s.charAt(i)) - 9;
//		}
//
//		int[] numbers = value.chars().map(c -> c - '0').toArray();
//
//		for (int i = 0; i < k; i++) {
//			sum = Arrays.stream(numbers).sum();
//			numbers = Integer.toString(sum).chars().map(c -> c - '0').toArray();
//		}
//
//		return sum;

		int sum = 0;
		for (int i = 0; i < s.length(); i++) {
			sum = sum + getSum(Character.getNumericValue(s.charAt(i)) - 9);
		}
		while (k-- > 1)
			sum = getSum(sum);

		return sum;

	}

	static int getSum(int n) {
		int sum = 0;
		while (n != 0) {
			sum = sum + n % 10;
			n = n / 10;
		}
		return sum;
	}

	/* https://leetcode.com/problems/check-if-string-is-a-prefix-of-array/ */
	public static boolean isPrefixString(String s, String[] words) {

//		System.out.println(isPrefixString("iloveleetcode", new String[] { "i", "love", "leetcode", "apples" }));

//		String temp = "";
//		for (String w : words) {
//			temp += w;
//			if (s.equalsIgnoreCase(temp)) {
//				return true;
//			} else if (!s.contains(temp)) {
//				return false;
//			}
//		}
//
//		return false;

		int count = 0;
		char[] chars = s.toCharArray();
		for (String word : words) {
			for (char c : word.toCharArray()) {
				if (count == chars.length) {
					return false;
				}
				if (chars[count++] != c) {
					return false;
				}
			}
			if (count == chars.length) {
				return true;
			}
		}
		return count == chars.length;

	}

	/* https://leetcode.com/problems/reverse-prefix-of-word/ */
	public static String reversePrefix(String word, char ch) {
		// System.out.println(reversePrefix("abcdefdz", 'z'));
		int i = -1;

		for (int j = 0; j < word.toCharArray().length; j++) {
			if (word.charAt(j) == ch) {
				i = j;
				break;
			}
		}

		if (i == -1)
			return word;

		StringBuilder sb = new StringBuilder(word.substring(0, i + 1));
		return sb.reverse() + word.substring(i + 1, word.length());
	}

	/* https://leetcode.com/problems/convert-1d-array-into-2d-array/ */
	public static int[][] construct2DArray(int[] original, int m, int n) {

		// construct2DArray(new int[] { 1, 2, 3 },1,3);

//		long total = Arrays.stream(original).count();
//
//		if (total != m * n)
//			return new int[][] {};
//
//		int[][] answer = new int[m][n];
//
//		for (int i = 0, j = 0, k = 0; i < m;) {
//			if (j == n) {
//				j = 0;
//				i++;
//			} else {
//				answer[i][j] = original[k];
//				j++;
//				k++;
//			}
//		}
//
//		return answer;

		if (original.length != m * n)
			return new int[][] {};

		int[][] answer = new int[m][n];

		for (int i = 0; i < original.length; i++) {
			answer[i / n][i % n] = original[i];
		}

		return answer;

	}

	/* https://leetcode.com/problems/two-out-of-three/ */
	public static List<Integer> twoOutOfThree(int[] nums1, int[] nums2, int[] nums3) {

		// System.out.println(twoOutOfThree(new int[] { 1, 1, 3, 2 }, new int[] { 2, 3,
		// 4, 4 }, new int[] { 3 }));

		List<Integer> list = new ArrayList<Integer>();
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (int i : Arrays.stream(nums1).boxed().collect(Collectors.toSet())) {
			map.put(i, map.getOrDefault(i, 0) + 1);
		}

		for (int i : Arrays.stream(nums2).boxed().collect(Collectors.toSet())) {
			map.put(i, map.getOrDefault(i, 0) + 1);
		}

		for (int i : Arrays.stream(nums3).boxed().collect(Collectors.toSet())) {
			map.put(i, map.getOrDefault(i, 0) + 1);
		}

		map.forEach((k, v) -> {
			if (v > 1)
				list.add(k);
		});

		return list;

		/*
		 * List<Integer> list = new ArrayList<Integer>(); Set<Integer> set = new
		 * HashSet<Integer>(); Map<Integer, Integer> map = new HashMap<Integer,
		 * Integer>();
		 * 
		 * for (int i : nums1) { set.add(i); }
		 * 
		 * list.addAll(set); set.clear();
		 * 
		 * for (int i : nums2) { set.add(i); }
		 * 
		 * list.addAll(set); set.clear();
		 * 
		 * for (int i : nums3) { set.add(i); }
		 * 
		 * list.addAll(set);
		 * 
		 * for (int i : list) { map.put(i, map.getOrDefault(i, 0) + 1); }
		 * 
		 * list.clear();
		 * 
		 * map.forEach((k, v) -> { if (v > 1) list.add(k); });
		 * 
		 * return list;
		 */
	}

	/* https://leetcode.com/problems/divide-a-string-into-groups-of-size-k/ */
	public static String[] divideString(String s, int k, char fill) {

		// divideString("abcdefghii", 2, 'x');

		String[] ans = new String[(s.length() % k) == 0 ? (s.length() / k) : (s.length() / k) + 1];
		String temp = "";

		for (int i = 0, l = k, j = 0; i < ans.length; i++, j = l, l += k) {
			if (l < s.length()) {
				ans[i] = s.subSequence(j, l).toString();
			} else {
				while (j < s.length()) {
					temp += s.charAt(j);
					j++;
				}
				while (j < l) {
					temp += fill;
					j++;
				}
				ans[i] = temp;
			}
		}

		return ans;

	}

	/* https://leetcode.com/problems/remove-digit-from-number-to-maximize-result/ */
	public static String removeDigit(String number, char digit) {

//		System.out.println(removeDigit(
//		"2998589353917872714814599237991174513476623756395992135212546127959342974628712329595771672911914471",
//		'3'));

		System.out.println(removeDigit("1233", '3'));

//		String temp = "", ans = "";
//		long tempVal = 0, currentVal = 0;
//		StringBuilder sb = new StringBuilder(number);
//
//		for (int i = 0; i < number.toCharArray().length; i++) {
//			if (number.charAt(i) == digit) {
//				temp = sb.deleteCharAt(i).toString();
//				currentVal = Long.parseLong(temp);
//				if (currentVal > tempVal) {
//					tempVal = currentVal;
//					ans = temp;
//				}
//				sb.insert(i, digit);
//			}
//		}
//		return ans;

		List<String> list = new ArrayList<String>();

		for (int i = 0; i < number.length(); i++) {
			if (number.charAt(i) == digit) {
				list.add(number.substring(0, i) + number.substring(i + 1));
			}
		}

		Collections.sort(list);
		return list.get(list.size() - 1);
	}

	/* https://leetcode.com/problems/count-hills-and-valleys-in-an-array/ */
	public static int countHillValley(int[] a) {
		// System.out.println(countHillValley(new int[] { 2, 4, 1, 1, 6, 5 }));

//		int length = nums.length;
//		int j = 0, k = 0, hillsAndValleys = 0;
//
//		for (int i = 0; i < length; i++) {
//			k = j = i;
//			if (i != 0 && i != length - 1) {
//
//				while (j != 0) {
//					if (nums[i] != nums[--j])
//						break;
//				}
//
//				while (k < length) {
//					if (nums[i] != nums[++k])
//						break;
//				}
//								
//				hillsAndValleys = ((nums[i] > nums[j] && nums[i] > nums[k]) || (nums[i] < nums[j] && nums[i] < nums[k]))
//						? hillsAndValleys + 1
//						: hillsAndValleys + 0;
//				k = j = 0;
//			}
//		}
//		return hillsAndValleys;

		int r = 0, left = a[0];
		for (int i = 1; i < a.length - 1; i++) {
			System.out.println(left);
			System.out.println(a[i]);
			System.out.println(a[i + 1]);
			if (left < a[i] && a[i] > a[i + 1] || left > a[i] && a[i] < a[i + 1]) {
				r++;
				left = a[i];
			}
		}
		return r;
	}

	/* https://leetcode.com/problems/find-the-difference-of-two-arrays/ */
	public static List<List<Integer>> findDifference(int[] nums1, int[] nums2) {

		// System.out.println(findDifference(new int[] { 1, 2, 3, 3 }, new int[] { 1, 1,
		// 2, 2 }));

		List<List<Integer>> answer = new ArrayList<List<Integer>>();
		Set<Integer> list1 = new HashSet<Integer>();
		Set<Integer> list2 = new HashSet<Integer>();

		for (int i : nums1) {
			list1.add(i);
		}

		for (int i : nums2) {
			list2.add(i);
		}

		answer.add(new ArrayList<Integer>());
		answer.add(new ArrayList<Integer>());

		for (int i : list1) {
			if (!list2.contains(i)) {
				answer.get(0).add(i);
			}
		}

		for (int i : list2) {
			if (!list1.contains(i)) {
				answer.get(1).add(i);
			}
		}

		return answer;
	}

	/* Service now */
	// Input: this is a great day
	// output: yadt ae r gasis iht
	public static String reverseStringPreserveSpace(String s) {

//		reverseStringPreserveSpace("this is a great day");

		char[] ans = new char[s.length()];
		String reversed = "";
		int k = 0;

		for (int i = s.length() - 1; i >= 0; i--) {
			reversed += s.charAt(i);
		}
		reversed = reversed.replaceAll(" ", "");

		for (int j = 0; j < s.length(); j++) {
			ans[j] = Character.isWhitespace(s.charAt(j)) ? ans[j] = ' ' : reversed.charAt(k++);
		}

		return String.valueOf(ans);
	}

	/* https://leetcode.com/problems/min-max-game/ */
	public int minMaxGame(int[] nums) {

//		if (nums.length == 1)
//			return nums[0];
//
//		int ans[] = new int[nums.length / 2];
//		for (int i = 0, j = 1, k = 0; i < nums.length && j < nums.length;) {
//			if (k % 2 == 0) {
//				ans[k] = Math.min(nums[i], nums[j]);
//			} else {
//				ans[k] = Math.max(nums[i], nums[j]);
//			}
//			i += 2;
//			j += 2;
//			k++;
//		}
//
//		return minMaxGame(ans);

//		if (nums.length == 1)
//			return nums[0];
//
//		int ans[] = new int[nums.length / 2];
//
//		for (int i = 0; i < nums.length && (2 * i) + 1 < nums.length; i++) {
//			ans[i] = i % 2 == 0 ? Math.min(nums[i * 2], nums[(2 * i) + 1]) : Math.max(nums[i * 2], nums[(2 * i) + 1]);
//		}
//
//		return minMaxGame(ans);

		for (int n = nums.length; n > 1; n -= (n / 2)) {
			for (int i = 0; i < n / 2; i++)
				nums[i] = (i % 2) == 1 ? Math.max(nums[2 * i], nums[2 * i + 1])
						: Math.min(nums[2 * i], nums[2 * i + 1]);
		}
		return nums[0];
	}

	/*
	 * Given an integer array nums, return true if any value appears at least twice
	 * in the array, and return false if every element is distinct.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: nums = [1,2,3,1] Output: true
	 */
	public boolean containsDuplicate(int[] nums) {

//		Set<Integer> set = new HashSet<Integer>();
//
//		for (int i : nums) {
//			if (!set.add(i))
//				return true;
//		}
//
//		return false;

//		Set<Integer> set = new HashSet<Integer>(Arrays.stream(nums).boxed().collect(Collectors.toSet()));
//
//		if (set.size() < nums.length)
//			return true;
//
//		return false;

		return new HashSet<Integer>(Arrays.stream(nums).boxed().collect(Collectors.toSet())).size() != nums.length;
	}

	/*
	 * Given an integer array nums, return the most frequent even element.
	 * 
	 * If there is a tie, return the smallest one. If there is no such element,
	 * return -1.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: nums = [0,1,2,2,4,4,1] Output: 2 Explanation: The even elements are 0,
	 * 2, and 4. Of these, 2 and 4 appear the most. We return the smallest one,
	 * which is 2.
	 */

	public int mostFrequentEven(int[] nums) {
//		int highRepetatedEven = Integer.MIN_VALUE;
		int ans = 0;

		Map<Integer, Integer> repetatedEvens = new HashMap<Integer, Integer>();

		for (int n : nums) {
			if (n % 2 == 0) {
				repetatedEvens.put(n, repetatedEvens.getOrDefault(n, 0) + 1);
			}
		}

		if (repetatedEvens.isEmpty())
			return -1;

//		repetatedEvens.forEach((k, v) -> {
//			if (v > highRepetatedEven) {
//				highRepetatedEven = v;
//				ans = k;
//			} else if (v == highRepetatedEven) {
//				ans = Math.min(ans, k);
//			}
//		});

		return ans;

	}

	/*
	 * A sentence is a list of words that are separated by a single space with no
	 * leading or trailing spaces.
	 * 
	 * You are given an array of strings sentences, where each sentences[i]
	 * represents a single sentence.
	 * 
	 * Return the maximum number of words that appear in a single sentence.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: sentences = ["alice and bob love leetcode", "i think so too",
	 * "this is great thanks very much"] Output: 6 Explanation: - The first
	 * sentence, "alice and bob love leetcode", has 5 words in total. - The second
	 * sentence, "i think so too", has 4 words in total. - The third sentence,
	 * "this is great thanks very much", has 6 words in total. Thus, the maximum
	 * number of words in a single sentence comes from the third sentence, which has
	 * 6 words.
	 */
	public int mostWordsFound(String[] sentences) {
		int mostWords = 0;
		for (String sentense : sentences) {
			mostWords = Math.max(sentense.split(" ").length, mostWords);
		}
		return mostWords;
	}

	/*
	 * You are given an m x n integer grid accounts where accounts[i][j] is the
	 * amount of money the i​​​​​​​​​​​​​​​ customer has in the j​​​​​​​​​​​​​​​
	 * bank. Return the wealth that the richest customer has.
	 * 
	 * A customer's wealth is the amount of money they have in all their bank
	 * accounts. The richest customer is the customer that has the maximum wealth.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: accounts = [[1,2,3],[3,2,1]] Output: 6 Explanation: 1st customer has
	 * wealth = 1 + 2 + 3 = 6 2nd customer has wealth = 3 + 2 + 1 = 6 Both customers
	 * are considered the richest with a wealth of 6 each, so return 6.
	 */
	public int maximumWealth(int[][] accounts) {

		int richest = 0, sum;

		for (int i = 0; i < accounts.length; i++) {
			sum = 0;
			for (int j : accounts[i]) {
				sum += j;
			}
			richest = Math.max(sum, richest);
		}
		return richest;
	}

	/*
	 * Given the array nums consisting of 2n elements in the form
	 * [x1,x2,...,xn,y1,y2,...,yn].
	 * 
	 * Return the array in the form [x1,y1,x2,y2,...,xn,yn].
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: nums = [2,5,1,3,4,7], n = 3 Output: [2,3,5,4,1,7] Explanation: Since
	 * x1=2, x2=5, x3=1, y1=3, y2=4, y3=7 then the answer is [2,3,5,4,1,7].
	 */

	public int[] shuffle(int[] nums, int n) {
//		int j = 0, k = 0;
//		int[] x = new int[3];
//		int[] y = new int[3];
//
//		System.arraycopy(nums, 0, x, 0, 3);
//		System.arraycopy(nums, n, y, 0, 3);
//
//		for (int i = 0; i < nums.length; i++) {
//			if (i % 2 == 0) {
//				nums[i] = x[j];
//				j++;
//			} else {
//				nums[i] = y[k];
//				k++;
//			}
//		}
//		return nums;

		int ans[] = new int[n * 2];
		int j = 0;
		for (int i = 0; i < nums.length; i++) {
			if (i % 2 != 0) {
				ans[i] = nums[n];
				n++;
			} else {
				ans[i] = nums[j];
				j++;
			}
		}
		return ans;
	}

	/*
	 * There is a programming language with only four operations and one variable X:
	 * 
	 * ++X and X++ increments the value of the variable X by 1. --X and X--
	 * decrements the value of the variable X by 1. Initially, the value of X is 0.
	 * 
	 * Given an array of strings operations containing a list of operations, return
	 * the final value of X after performing all the operations.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: operations = ["--X","X++","X++"] Output: 1 Explanation: The operations
	 * are performed as follows: Initially, X = 0. --X: X is decremented by 1, X = 0
	 * - 1 = -1. X++: X is incremented by 1, X = -1 + 1 = 0. X++: X is incremented
	 * by 1, X = 0 + 1 = 1.
	 */

	public int finalValueAfterOperations(String[] operations) {
		int val = 0;

		for (String str : operations) {
			if (str.contains("+")) {
				val++;
			} else {
				val--;
			}
		}

		return val;
	}

	/*
	 * Given an array nums. We define a running sum of an array as runningSum[i] =
	 * sum(nums[0]…nums[i]).
	 * 
	 * Return the running sum of nums.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: nums = [1,2,3,4] Output: [1,3,6,10] Explanation: Running sum is
	 * obtained as follows: [1, 1+2, 1+2+3, 1+2+3+4].
	 */

	public int[] runningSum(int[] nums) {

//		int j = 0, sum = 0;
//		int[] ans = new int[nums.length];
//
//		for (int i = 0; i < nums.length; i++) {
//			while (j <= i) {
//				sum += nums[j];
//				j++;
//			}
//			ans[i] = sum;
//			j = 0;
//			sum = 0;
//		}
//		return ans;

		for (int i = 1; i < nums.length; i++) {
			nums[i] += nums[i - 1];
		}
		return nums;
	}

	/*
	 * Given an integer array nums of length n, you want to create an array ans of
	 * length 2n where ans[i] == nums[i] and ans[i + n] == nums[i] for 0 <= i < n
	 * (0-indexed).
	 * 
	 * Specifically, ans is the concatenation of two nums arrays.
	 * 
	 * Return the array ans.
	 * 
	 * Input: nums = [1,2,1] Output: [1,2,1,1,2,1] Explanation: The array ans is
	 * formed as follows: - ans = [nums[0],nums[1],nums[2],nums[0],nums[1],nums[2]]
	 * - ans = [1,2,1,1,2,1]
	 */

	public int[] getConcatenation(int[] nums) {
		int[] ans = Arrays.copyOf(nums, nums.length * 2);
		int fromLen = ans.length / 2;
		System.arraycopy(nums, 0, ans, fromLen, fromLen);
		return ans;
	}

	/*
	 * You are given two strings current and correct representing two 24-hour times.
	 * 
	 * 24-hour times are formatted as "HH:MM", where HH is between 00 and 23, and MM
	 * is between 00 and 59. The earliest 24-hour time is 00:00, and the latest is
	 * 23:59.
	 * 
	 * In one operation you can increase the time current by 1, 5, 15, or 60
	 * minutes. You can perform this operation any number of times.
	 * 
	 * Return the minimum number of operations needed to convert current to correct.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: current = "02:30", correct = "04:35" Output: 3 Explanation: We can
	 * convert current to correct in 3 operations as follows: - Add 60 minutes to
	 * current. current becomes "03:30". - Add 60 minutes to current. current
	 * becomes "04:30". - Add 5 minutes to current. current becomes "04:35". It can
	 * be proven that it is not possible to convert current to correct in fewer than
	 * 3 operations.
	 */
	public int convertTime(String current, String correct) {

		int currentTimeInMinutes = Integer.valueOf(current.split(":")[0]) * 60 + Integer.valueOf(current.split(":")[1]);
		int correctTimeInMinutes = Integer.valueOf(correct.split(":")[0]) * 60 + Integer.valueOf(correct.split(":")[1]);
		int noOfOperations = 0;

		while (currentTimeInMinutes < correctTimeInMinutes) {
			if (!((currentTimeInMinutes + 60) > correctTimeInMinutes)) {
				currentTimeInMinutes += 60;
			} else if (!((currentTimeInMinutes + 15) > correctTimeInMinutes)) {
				currentTimeInMinutes += 15;
			} else if (!((currentTimeInMinutes + 5) > correctTimeInMinutes)) {
				currentTimeInMinutes += 5;
			} else if (!((currentTimeInMinutes + 1) > correctTimeInMinutes)) {
				currentTimeInMinutes += 1;
			}
			noOfOperations++;
		}
		return noOfOperations;
	}

	/*
	 * You are given the strings key and message, which represent a cipher key and a
	 * secret message, respectively. The steps to decode message are as follows:
	 * 
	 * Use the first appearance of all 26 lowercase English letters in key as the
	 * order of the substitution table. Align the substitution table with the
	 * regular English alphabet. Each letter in message is then substituted using
	 * the table. Spaces ' ' are transformed to themselves. For example, given key =
	 * "happy boy" (actual key would have at least one instance of each letter in
	 * the alphabet), we have the partial substitution table of ('h' -> 'a', 'a' ->
	 * 'b', 'p' -> 'c', 'y' -> 'd', 'b' -> 'e', 'o' -> 'f').
	 */

	public String decodeMessage(String key, String message) {
		Map<Character, Character> keyAndValeus = new TreeMap<Character, Character>();
		char keyName = 'a';
		for (char c : key.replaceAll(" ", "").toCharArray())
			if (!keyAndValeus.containsKey(c)) {
				keyAndValeus.put(c, keyName);
				keyName++;
			}

		StringBuilder sb = new StringBuilder();

		for (char c : message.toCharArray()) {
			if (!Character.isWhitespace(c)) {
				sb.append(keyAndValeus.get(c));
			} else {
				sb.append(c);
			}
		}

		return sb.toString();
	}

	/*
	 * A password is said to be strong if it satisfies all the following criteria:
	 * 
	 * It has at least 8 characters. It contains at least one lowercase letter. It
	 * contains at least one uppercase letter. It contains at least one digit. It
	 * contains at least one special character. The special characters are the
	 * characters in the following string: "!@#$%^&*()-+". It does not contain 2 of
	 * the same character in adjacent positions (i.e., "aab" violates this
	 * condition, but "aba" does not). Given a string password, return true if it is
	 * a strong password. Otherwise, return false.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: password = "IloveLe3tcode!" Output: true Explanation: The password
	 * meets all the requirements. Therefore, we return true
	 */
	public boolean strongPasswordCheckerII(String password) {
		Set<Character> seen = new HashSet<>();
		for (int i = 0; i < password.length(); ++i) {
			char c = password.charAt(i);
			if (i > 0 && c == password.charAt(i - 1)) {
				return false;
			}
			if (Character.isLowerCase(c)) {
				seen.add('l');
			} else if (Character.isUpperCase(c)) {
				seen.add('u');
			} else if (Character.isDigit(c)) {
				seen.add('d');
			} else {
				seen.add('s');
			}
		}
		return password.length() >= 8 && seen.size() == 4;
	}

	/*
	 * Given an integer array nums of size n, return the number with the value
	 * closest to 0 in nums. If there are multiple answers, return the number with
	 * the largest value.
	 * 
	 * 
	 * 
	 * Example 1: Input: nums = [2,-1,1] Output: 1 Explanation: 1 and -1 are both
	 * the closest numbers to 0, so 1 being larger is returned.
	 */
	public int findClosestNumber(int[] nums) {
		int distNums[] = new int[nums.length];
		int minNum = 0, j = 0;

		for (int i = 0; i < nums.length; i++) {
			distNums[i] = Math.abs(nums[i]);
		}

		minNum = Arrays.stream(distNums).min().getAsInt();

		for (j = 0; j < nums.length; j++) {
			if (nums[j] == minNum)
				return nums[j];
		}

		for (j = 0; j < nums.length; j++) {
			if (nums[j] == -minNum)
				return nums[j];
		}
		return j;

//		int min = Integer.MAX_VALUE, closest_num = 0;
//		for (int n : nums) {
//			if (min > Math.abs(n)) {
//				min = Math.abs(n);
//				closest_num = n;
//			} else if (min == Math.abs(n) && closest_num < n) {
//				closest_num = n;
//			}
//		}
//		return closest_num;

	}

	/*
	 * A phrase is a palindrome if, after converting all uppercase letters into
	 * lowercase letters and removing all non-alphanumeric characters, it reads the
	 * same forward and backward. Alphanumeric characters include letters and
	 * numbers.
	 * 
	 * Given a string s, return true if it is a palindrome, or false otherwise.
	 */
	public boolean isPalindrome(String s) {
		s = s.toLowerCase().replaceAll("[^a-z0-9]", "");
		StringBuilder sb = new StringBuilder(s);
		sb.reverse();
		return s.equals(sb.toString());
	}

	/*
	 * Given the head of a sorted linked list, delete all duplicates such that each
	 * element appears only once. Return the linked list sorted as well. Input: head
	 * = [1,1,2] Output: [1,2]
	 */

	public List<Integer> deleteDuplicates(List<Integer> head) {
		Collections.sort(head);
		Set<Integer> unique = new TreeSet<Integer>(head);
		System.out.println(unique);
		return head;
	}

	/*
	 * You are climbing a staircase. It takes n steps to reach the top.
	 * 
	 * Each time you can either climb 1 or 2 steps. In how many distinct ways can
	 * you climb to the top?
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: n = 2 Output: 2 Explanation: There are two ways to climb to the top.
	 * 1. 1 step + 1 step 2. 2 steps
	 */

	public int climbStairs(int n) {
		int a = 0, b = 2, c = 1;
		Map<Integer, Integer> fibonicSeries = new HashMap<Integer, Integer>();
		fibonicSeries.put(1, c);
		fibonicSeries.put(2, b);
		for (int i = 3; i < 46; i++) {
			a = b + c;
			c = b;
			b = a;
			fibonicSeries.put(i, a);

		}
		return fibonicSeries.get(n);
	}

	/*
	 * Given a sentence that consists of some words separated by a single space, and
	 * a searchWord, check if searchWord is a prefix of any word in sentence.
	 * 
	 * Return the index of the word in sentence (1-indexed) where searchWord is a
	 * prefix of this word. If searchWord is a prefix of more than one word, return
	 * the index of the first word (minimum index). If there is no such word return
	 * -1.
	 * 
	 * A prefix of a string s is any leading contiguous substring of s.
	 * 
	 * Input: sentence = "i love eating burger", searchWord = "burg" Output: 4
	 * Explanation: "burg" is prefix of "burger" which is the 4th word in the
	 * sentence.
	 */

	public int isPrefixOfWord(String sentence, String searchWord) {

		String[] wordsInSentence = sentence.split(" ");

		for (int i = 0; i < wordsInSentence.length; i++) {
			if (wordsInSentence[i].startsWith(searchWord)) {
				System.out.println(i + 1);
				return i + 1;
			}
		}
		return -1;
	}

	/*
	 * Given a signed 32-bit integer x, return x with its digits reversed. If
	 * reversing x causes the value to go outside the signed 32-bit integer range
	 * [-231, 231 - 1], then return 0.
	 * 
	 * Assume the environment does not allow you to store 64-bit integers (signed or
	 * unsigned).
	 * 
	 * Example 1: Input: x = 123 Output: 321
	 */

	public int reverse(int x) {
		String[] number;
		int reversedNumber;
		try {
			if (x < 0) {
				number = String.valueOf(x).substring(1).split("");
				Collections.reverse(Arrays.asList(number));
				reversedNumber = Integer.valueOf(String.join("", number));
				System.out.println(-reversedNumber);
				return -reversedNumber;
			} else {
				number = String.valueOf(x).split("");
				Collections.reverse(Arrays.asList(number));
				reversedNumber = Integer.valueOf(String.join("", number));
				System.out.println(reversedNumber);
				return reversedNumber;
			}
		} catch (Exception e) {
			return 0;
		}
	}

	/*
	 * Given an integer x, return true if x is palindrome integer.
	 * 
	 * An integer is a palindrome when it reads the same backward as forward.
	 * 
	 * For example, 121 is a palindrome while 123 is not.
	 */

	public boolean isPalindrome(int x) {
		StringBuilder stringBuilder = new StringBuilder(String.valueOf(x)).reverse();
		if (stringBuilder.toString().equals(stringBuilder.reverse().toString())) {
			return true;
		}
		return false;
	}

	/*
	 * Given a string s containing just the characters '(', ')', '{', '}', '[' and
	 * ']', determine if the input string is valid.
	 * 
	 * An input string is valid if:
	 * 
	 * Open brackets must be closed by the same type of brackets. Open brackets must
	 * be closed in the correct order.
	 */
	public boolean isValid(String s) {
		Stack<Character> resultStack = new Stack<Character>();
		for (char c : s.toCharArray()) {
			if (c == ('(')) {
				resultStack.push(')');
			} else if (c == ('{')) {
				resultStack.push('}');
			} else if (c == ('[')) {
				resultStack.push(']');
			} else if (resultStack.isEmpty() || resultStack.pop() != c) {
				return false;
			}
		}
		return resultStack.isEmpty();
	}

	/*
	 * Given a string s consisting of only the characters 'a' and 'b', return true
	 * if every 'a' appears before every 'b' in the string. Otherwise, return false.
	 */
	public boolean checkString(String s) {
		if (!(s.contains("a")) || !(s.contains("ba"))) {
			return true;
		}
		return false;
	}

	/*
	 * Given a string s consisting of words and spaces, return the length of the
	 * last word in the string.
	 * 
	 * A word is a maximal substring consisting of non-space characters only.
	 */
	public int lengthOfLastWord(String s) {
		return s.split(" ")[s.split(" ").length - 1].length();
	}

	/*
	 * Given a list of strings words and a string pattern, return a list of words[i]
	 * that match pattern. You may return the answer in any order.
	 * 
	 * A word matches the pattern if there exists a permutation of letters p so that
	 * after replacing every letter x in the pattern with p(x), we get the desired
	 * word.
	 * 
	 * Recall that a permutation of letters is a bijection from letters to letters:
	 * every letter maps to another letter, and no two letters map to the same
	 * letter.
	 */
	public List<String> findAndReplacePattern(String[] words, String pattern) {
		List<Integer> repitativeLettersInPatters = repativeLettersInWord(pattern.split(""));
		List<String> matchingPatterns = new ArrayList<String>();

		for (int k = 0; k < words.length; k++) {
			if (repitativeLettersInPatters.equals(repativeLettersInWord(words[k].split("")))) {
				matchingPatterns.add(words[k]);
			}
		}
		return matchingPatterns;
	}

	public List<Integer> repativeLettersInWord(String[] word) {
		List<Integer> repetativeElementsLocation = new ArrayList<Integer>();
		/* Checking for repetitive letters in pattern. */
		for (int i = 0; i < word.length; i++) {
			for (int j = 0; j < word.length; j++) {
				if (i != j && word[i].equals(word[j])) {
					repetativeElementsLocation.add(1);
				} else {
					repetativeElementsLocation.add(0);
				}
			}
		}
		return repetativeElementsLocation;
	}

	/*
	 * Given two strings s and t, return true if t is an anagram of s, and false
	 * otherwise.
	 * 
	 * An Anagram is a word or phrase formed by rearranging the letters of a
	 * different word or phrase, typically using all the original letters exactly
	 * once.
	 */
	public boolean isAnagram(String s, String t) {
		return charactersOfString(s).equals(charactersOfString(t));
	}

	public List<String> charactersOfString(String s) {
		List<String> allCharacters = new ArrayList<String>();
		allCharacters.addAll(Arrays.asList(s.split("")));
		Collections.sort(allCharacters);
		return allCharacters;
	}

	/*
	 * Given an integer num, return the number of steps to reduce it to zero.
	 * 
	 * In one step, if the current number is even, you have to divide it by 2,
	 * otherwise, you have to subtract 1 from it.
	 */
	public int numberOfSteps(int num) {
		if (num == 0) {
			return 0;
		} else {
			int steps = 0;
			while (num != 0) {
				num = num % 2 == 0 ? num / 2 : num - 1;
				steps++;
			}
			return steps;
		}
	}

	/*
	 * You are given a large integer represented as an integer array digits, where
	 * each digits[i] is the ith digit of the integer. The digits are ordered from
	 * most significant to least significant in left-to-right order. The large
	 * integer does not contain any leading 0's.
	 * 
	 * Increment the large integer by one and return the resulting array of digits.
	 */

	public int[] plusOne(int[] digits) {

		int carry = 1;
		for (int i = digits.length - 1; i >= 0; i--) {
			digits[i] += carry;
			if (digits[i] <= 9) // early return
				return digits;
			digits[i] = 0;
		}
		int[] ret = new int[digits.length + 1];
		ret[0] = 1;
		return ret;

	}

	/*
	 * Given two binary strings a and b, return their sum as a binary string.
	 *
	 * Example 1:
	 * 
	 * Input: a = "11", b = "1" Output: "100" Example 2:
	 * 
	 * Input: a = "1010", b = "1011" Output: "10101"
	 */
	public String addBinary(String a, String b) {
		// If the inputs are 0
		if (a.charAt(0) == '0' && b.charAt(0) == '0') {
			return "0";
		}
		// Initialize result
		StringBuilder result = new StringBuilder("");

		// Initialize digit sum
		int s = 0;

		// Traverse both strings starting
		// from last characters
		int i = a.length() - 1, j = b.length() - 1;
		while (i >= 0 || j >= 0 || s == 1) {

			// Comput sum of last
			// digits and carry
			s += ((i >= 0) ? a.charAt(i) - '0' : 0);
			s += ((j >= 0) ? b.charAt(j) - '0' : 0);

			// If current digit sum is
			// 1 or 3, add 1 to result
			result.append((char) (s % 2 + '0'));

			// Compute carry
			s /= 2;

			// Move to next digits
			i--;
			j--;
		}

		// Remove leading zeros, if any
		int start = result.length() - 1;

		while (start >= 0 && result.charAt(start) == '0') {
			start--;
		}

		if (start != result.length() - 1) {
			result.delete(start + 1, result.length());
		}

		return result.reverse().toString();
	}

	/*
	 * Given a string paragraph and a string array of the banned words banned,
	 * return the most frequent word that is not banned. It is guaranteed there is
	 * at least one word that is not banned, and that the answer is unique.
	 * 
	 * The words in paragraph are case-insensitive and the answer should be returned
	 * in lowercase.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: paragraph = "Bob hit a ball, the hit BALL flew far after it was hit.",
	 * banned = ["hit"] Output: "ball" Explanation: "hit" occurs 3 times, but it is
	 * a banned word. "ball" occurs twice (and no other word does), so it is the
	 * most frequent non-banned word in the paragraph. Note that words in the
	 * paragraph are not case sensitive, that punctuation is ignored (even if
	 * adjacent to words, such as "ball,"), and that "hit" isn't the answer even
	 * though it occurs more because it is banned. Example 2:
	 * 
	 * Input: paragraph = "a.", banned = [] Output: "a"
	 */
	public String mostCommonWord(String paragraph, String[] banned) {

		paragraph = paragraph.replaceAll("[!?',;.]", " ").toLowerCase();
		List<String> para = new ArrayList<String>(Arrays.asList(paragraph.split(" ")));
		para.removeAll(Collections.singleton(""));
		System.out.println(para);
		for (String string : banned) {
			para.removeAll(Collections.singleton(string));
		}
		Map.Entry<String, Long> key = para.stream()
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting())).entrySet().stream()
				.max(Map.Entry.comparingByValue()).get();
		return key.getKey();
	}

	/*
	 * You are given two 2D integer arrays, items1 and items2, representing two sets
	 * of items. Each array items has the following properties:
	 * 
	 * items[i] = [valuei, weighti] where valuei represents the value and weighti
	 * represents the weight of the ith item. The value of each item in items is
	 * unique. Return a 2D integer array ret where ret[i] = [valuei, weighti], with
	 * weighti being the sum of weights of all items with value valuei.
	 * 
	 * Note: ret should be returned in ascending order by value.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: items1 = [[1,1],[4,5],[3,8]], items2 = [[3,1],[1,5]] Output:
	 * [[1,6],[3,9],[4,5]] Explanation: The item with value = 1 occurs in items1
	 * with weight = 1 and in items2 with weight = 5, total weight = 1 + 5 = 6. The
	 * item with value = 3 occurs in items1 with weight = 8 and in items2 with
	 * weight = 1, total weight = 8 + 1 = 9. The item with value = 4 occurs in
	 * items1 with weight = 5, total weight = 5. Therefore, we return
	 * [[1,6],[3,9],[4,5]].
	 */

	public List<List<Integer>> mergeSimilarItems(int[][] items1, int[][] items2) {
		TreeMap<Integer, Integer> cnt = new TreeMap<>();
		Stream.of(items1).forEach(item -> cnt.put(item[0], item[1]));
		Stream.of(items2).forEach(item -> cnt.merge(item[0], item[1], Integer::sum));
		return cnt.entrySet().stream().map(e -> Arrays.asList(e.getKey(), e.getValue())).collect(Collectors.toList());
	}

	/*
	 * You are given a 0-indexed, strictly increasing integer array nums and a
	 * positive integer diff. A triplet (i, j, k) is an arithmetic triplet if the
	 * following conditions are met:
	 * 
	 * i < j < k, nums[j] - nums[i] == diff, and nums[k] - nums[j] == diff. Return
	 * the number of unique arithmetic triplets.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: nums = [0,1,4,6,7,10], diff = 3 Output: 2 Explanation: (1, 2, 4) is an
	 * arithmetic triplet because both 7 - 4 == 3 and 4 - 1 == 3. (2, 4, 5) is an
	 * arithmetic triplet because both 10 - 7 == 3 and 7 - 4 == 3.
	 */

	public int arithmeticTriplets(int[] nums, int diff) {
//		 int cnt = 0;
//	        Set<Integer> seen = new HashSet<>();
//	        for (int num : nums) {
//	            if (seen.contains(num - diff) && seen.contains(num - diff * 2)) {
//	                ++cnt;
//	            }
//	            seen.add(num);
//	        }
//	        return cnt;

		int count = 0;

		for (int i = 0; i < nums.length - 2; i++) {
			for (int j = i + 1; j < nums.length - 1; j++) {
				for (int k = j + 1; k < nums.length; k++) {
					if (nums[j] - nums[i] == diff && nums[k] - nums[j] == diff)
						count++;
				}
			}
		}
		return count;

	}

	/*
	 * Given a string s consisting of lowercase English letters, return the first
	 * letter to appear twice.
	 * 
	 * Note:
	 * 
	 * A letter a appears twice before another letter b if the second occurrence of
	 * a is before the second occurrence of b. s will contain at least one letter
	 * that appears twice.
	 * 
	 * 
	 * Input: s = "abccbaacz" Output: "c"
	 */

	public char repeatedCharacter(String s) {
		Set<Character> letters = new HashSet<Character>();
		for (char c : s.toCharArray()) {
			if (!letters.add(c)) {
				return c;
			}
		}
		return 0;
	}

	/*
	 * You are given a 0-indexed integer array nums. In one operation, you may do
	 * the following:
	 * 
	 * Choose two integers in nums that are equal. Remove both integers from nums,
	 * forming a pair. The operation is done on nums as many times as possible.
	 * 
	 * Return a 0-indexed integer array answer of size 2 where answer[0] is the
	 * number of pairs that are formed and answer[1] is the number of leftover
	 * integers in nums after doing the operation as many times as possible.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: nums = [1,3,2,1,3,2,2] Output: [3,1]
	 */

	public int[] numberOfPairs(int[] nums) {
//		int numberOfPairs = 0, numberOfLeftOverIntegers = 0;
//		List<Integer> numList = new ArrayList<Integer>(Arrays.stream(nums).boxed().collect(Collectors.toList()));
//		if (numList.size() > 0) {
//			Map<Integer, Long> repeatativeCount = numList.stream()
//					.collect(Collectors.groupingBy(c -> c, Collectors.counting()));
//
//			Set<Map.Entry<Integer, Long>> keysAndValue = repeatativeCount.entrySet();
//			Iterator<Map.Entry<Integer, Long>> iterator = keysAndValue.iterator();
//			while (iterator.hasNext()) {
//				Map.Entry<Integer, Long> entry = (Map.Entry<Integer, Long>) iterator.next();
//				numberOfPairs = numberOfPairs + (int) (entry.getValue() / 2);
//				numberOfLeftOverIntegers = numberOfLeftOverIntegers + (int) (entry.getValue() % 2);
//			}
//			return new int[] { numberOfPairs, numberOfLeftOverIntegers };
//		}
//		return new int[] { 0, 1 };

		if (nums.length == 1)
			return new int[] { 0, 1 };

		HashSet<Integer> set = new HashSet<>();

		int pairs = 0;
		for (int i : nums) {
			if (!set.contains(i)) {
				set.add(i); // No pair present
			} else {
				set.remove(i); // Pair found
				pairs++;
			}
		}

		return new int[] { pairs, set.size() };
	}

	/*
	 * Given a string s and a character letter, return the percentage of characters
	 * in s that equal letter rounded down to the nearest whole percent.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: s = "foobar", letter = "o" Output: 33 Explanation: The percentage of
	 * characters in s that equal the letter 'o' is 2 / 6 * 100% = 33% when rounded
	 * down, so we return 33.
	 */

	public int percentageLetter(String s, char letter) {
		int noOfTimes = 0;
		if (!s.contains(letter + ""))
			return 0;

		for (char c : s.toCharArray())
			if (c == letter)
				noOfTimes++;

		return Math.round(noOfTimes * 100 / s.length());
	}

	/*
	 * You have a water dispenser that can dispense cold, warm, and hot water. Every
	 * second, you can either fill up 2 cups with different types of water, or 1 cup
	 * of any type of water.
	 * 
	 * You are given a 0-indexed integer array amount of length 3 where amount[0],
	 * amount[1], and amount[2] denote the number of cold, warm, and hot water cups
	 * you need to fill respectively. Return the minimum number of seconds needed to
	 * fill up all the cups.
	 * 
	 * Input: amount = [1,4,2] Output: 4
	 */

	public int fillCups(int[] amount) {
		return Math.max(Arrays.stream(amount).max().getAsInt(), (Arrays.stream(amount).sum() + 1) / 2);
	}

	/*
	 * Given a non-negative integer x, compute and return the square root of x.
	 * 
	 * Since the return type is an integer, the decimal digits are truncated, and
	 * only the integer part of the result is returned.
	 * 
	 * Note: You are not allowed to use any built-in exponent function or operator,
	 * such as pow(x, 0.5) or x ** 0.5.
	 * 
	 * 
	 * 
	 * Example 1:
	 * 
	 * Input: x = 4 Output: 2
	 */
	public int mySqrt(int x) {
		long y = 0;
		while (y * y <= x) {
			y++;
		}
		return (int) (y - 1);
	}

	/* Problem#1 */
//	int[] inputArray = { 2, 7, 11, 15 };
//	javaProblems.twoSum(inputArray, 9);

	/* Problem#2 */
//	javaProblems.isPrefixOfWord("hellohello hellohellohello", "ell");

	/* Problem#3 */
//	javaProblems.reverse(564);

	/* Problem#4 */
//	javaProblems.longestPalindrome("abb");

	/* Problem#5 */
//	javaProblems.lengthOfLongestSubstring("pwwkew");

	/* Problem#6 */
//	String[] input = { "a" };
//	javaProblems.longestCommonPrefix(input);

	/* Problem#7 */
//	javaProblems.isPalindrome(121);

	/* Problem#8 */
//	javaProblems.isValid("(){}}{");

	/* Problem#9 */
//	System.out.println(javaProblems.checkString("abab"));

	/* Problem#10 */
//	System.out.println(javaProblems.searchRange(new int[] { 5, 7, 7, 8, 8, 10 }, 8));

	/* Problem#11 */
//	javaProblems.removeElement(new int[] { 0,1,2,2,3,0,4,2 }, 2);

	/* Problem#12 */
//	System.out.println(javaProblems.lengthOfLastWord("   fly me   to   the moon  "));

	/* Problem#13 */
//	System.out.println(javaProblems.findAndReplacePattern(new String[] { "a", "b", "c" }, "a"));

	/* Problem#14 */
//	System.out.println(javaProblems.isAnagram("anagram", "nagaram"));

	/* Problem#15 */
//	System.out.println(javaProblems.distributeCookies(new int[] { 20, 13, 18 }, 2));

	/* Problem#16 */
//	System.out.println(javaProblems.numberOfSteps(123));

	/* Problem#17 */
//	System.out.println(javaProblems.plusOne(new int[] { 2, 9 }));

	/* Problem#18 */
//	System.out.println(javaProblems.commonChars(new String[] { "bella","label","roller" }));

	/* Problem#19 */
//	System.out.println(javaProblems.addBinary("1010", "1011"));

	/* Problem#20 */
//	System.out.println(javaProblems.mostCommonWord("Bob hit a ball, the hit BALL flew far after it was hit.",
//			new String[] { "hit" }));

	/* Problem#21 */
//	System.out.println(javaProblems.mergeSimilarItems(new int[][] { { 1, 1 }, { 4, 5 }, { 3, 8 } },
//			new int[][] { { 3, 1 }, { 1, 5 } }));
//	System.out.println(javaProblems.mergeSimilarItems(new int[][] { { 1, 3 }, { 2, 2 } },
//			new int[][] { { 7, 1 }, { 2, 2 }, { 1, 4 } }));
//	System.out.println(
//			javaProblems.mergeSimilarItems(new int[][] { { 5, 1 }, { 4, 2 }, { 3, 3 }, { 2, 4 }, { 1, 5 } },
//					new int[][] { { 7, 1 }, { 6, 2 }, { 5, 3 }, { 4, 4 } }));
//	System.out.println(
//			javaProblems.mergeSimilarItems(new int[][] { { 5, 1 }, { 4, 2 }, { 3, 3 }, { 2, 4 }, { 1, 5 } },
//					new int[][] { { 7, 1 }, { 6, 2 }, { 5, 3 }, { 4, 4 } }));
	// [[1,5],[2,4],[3,3],[4,6],[5,4],[6,2],[7,1]]

	/* Problem#22 */
//	System.out.println(javaProblems.arithmeticTriplets(new int[] { 4, 5, 6, 7, 8, 9 }, 2));

	/* Problem#23 */
//	System.out.println(javaProblems.minimumOperations(new int[] { 2, 4, 3, 0, 1 }));
//	System.out.println(javaProblems.minimumOperations(new int[] { 1, 5, 0, 3, 5 }));

	/* Problem#24 */
//	System.out.println(javaProblems.repeatedCharacter("abccbaacz"));
//	System.out.println(javaProblems.repeatedCharacter("abcdd"));
//	System.out.println(javaProblems.repeatedCharacter("nwcn"));
//	System.out.println(javaProblems.repeatedCharacter("abccbaacz"));
//	System.out.println(javaProblems.repeatedCharacter("regzueqr"));

	/* Problem#25 */
//	System.out.println(javaProblems.numberOfPairs(new int[] { 1, 3, 2, 1, 3, 2, 2 }));
//	System.out.println(javaProblems.numberOfPairs(new int[] { 1, 1, 1, 2, 2, 4, 5 }));
//	System.out.println(javaProblems.numberOfPairs(new int[] { 1, 1 }));
//	System.out.println(javaProblems.numberOfPairs(new int[] { 0 }));

	/* Problem#26 */
//	System.out.println(javaProblems.percentageLetter("foobar", 'z'));
//	System.out.println(javaProblems.percentageLetter("sgawtb", 's'));

	/* Problem#27 */
//	System.out.println(javaProblems.fillCups(new int[] { 1, 4, 2 })); // 4
//	System.out.println(javaProblems.fillCups(new int[] { 5, 4, 4 })); // 7
//	System.out.println(javaProblems.fillCups(new int[] { 5, 1, 0 })); // 5
//	System.out.println(javaProblems.fillCups(new int[] { 5, 0, 0 }));// 5
//	System.out.println(javaProblems.fillCups(new int[] { 5, 1, 2 })); // 5
//	System.out.println(javaProblems.fillCups(new int[] { 3, 4, 5 }));// 6

	/* Problem#28 */
//	System.out.println(javaProblems.mySqrt(131));
//	System.out.println(javaProblems.mySqrt(2147395600));

	/* Problem#29 */
//	System.out.println(javaProblems.climbStairs(8));

	/* Problem#30 */
//	System.out.println(javaProblems.deleteDuplicates(new LinkedList<Integer>(Arrays.asList(1, 1, 2,3,3))));

	/* Problem#31 */
//	System.out.println(javaProblems.isPalindrome("0P"));

	/* Problem#32 */
//	System.out.println(javaProblems.findClosestNumber(new int[] { -4, -2, 1, 4, 8 }));
//	System.out.println(javaProblems.findClosestNumber(new int[] { -4, -2, -6, -7, 8, 0 }));

	/* Problem#33 */
//	System.out.println(javaProblems.strongPasswordCheckerII(
//			"$!)+-$-^(@)@#-(#)+@#*&%+*%($^%+)#()&)!)*()-+&$*@*)+%+*^!%!&!$#%-*!@&%!)%+()^$&+-"));

	/* Problem#33 */
//	System.out
//			.println(javaProblems.decodeMessage("the quick brown fox jumps over the lazy dog", "vkbs bs t suepuv"));
//	System.out
//	.println(javaProblems.decodeMessage("eljuxhpwnyrdgtqkviszcfmabo", "zwx hnfx lqantp mnoeius ycgk vcnjrdb"));
//	System.out.println(javaProblems.decodeMessage("a", "zwx hnfx lqantp mnoeius ycgk vcnjrdb"));

	/* Problem#34 */
//	System.out.println(javaProblems.convertTime("01:59", "05:45"));
//	System.out.println(javaProblems.convertTime("02:30", "04:35"));
//	System.out.println(javaProblems.convertTime("11:30", "11:31"));

	/* Problem#36 */
//	System.out.println(javaProblems.runningSum(new int[] { 3, 1, 2, 10, 1 }));

	/* Problem#37 */
//	System.out.println(javaProblems.finalValueAfterOperations(new String[] { "X--", "++X", "--X", "X--", "++X" }));

	/* Problem#38 */
//	System.out.println(javaProblems.shuffle(new int[] { 2, 5, 1, 3, 4, 7 }, 3));

	/* Problem#39 */
//	System.out.println(javaProblems.maximumWealth(new int[][] { { 1, 2, 3 }, { 3, 2, 1 } }));
//	System.out.println(javaProblems.maximumWealth(new int[][] { { 2, 8, 7 }, { 7, 1, 3 }, { 1, 9, 5 } }));

	/* Problem#40 */
//	System.out.println(javaProblems.mostWordsFound(
//			new String[] { "alice and bob love leetcode", "i think so too", "this is great thanks very much" }));

	/* Problem#41 */
//	System.out.println(javaProblems.mostFrequentEven(new int[] { 0, 1, 2, 2, 4, 4, 1 }));

	/* Problem#42 */
//	System.out.println(javaProblems.containsDuplicate(new int[] { 0, 1, 2, 2, 4, 4, 1 }));

	/* Problem#42 */
//	System.out.println(javaProblems.minMaxGame(new int[] { 1, 3, 5, 2, 4, 8, 2, 2 }));
}
