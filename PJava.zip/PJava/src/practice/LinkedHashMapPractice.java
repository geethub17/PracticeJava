package practice;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class LinkedHashMapPractice {

	public static void main(String[] args) {
		LinkedHashMap<Integer, String> linkedHashMap = new LinkedHashMap<Integer, String>();
		linkedHashMap.put(1, "Nandan1");
		linkedHashMap.put(2, "Nandan2");
		linkedHashMap.put(3, "Nandan3");
		linkedHashMap.put(4, "Nandan4");
		linkedHashMap.put(7, "Nandan7");
		linkedHashMap.put(10, "Nandan10");
		linkedHashMap.put(10, "Nandan10");

		for (Map.Entry m : linkedHashMap.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}

		linkedHashMap.forEach((k, v) -> {
			System.out.println(k);
			System.out.println(v);
		});

		Set<Entry<Integer, String>> entries = linkedHashMap.entrySet();
		Iterator<Entry<Integer, String>> iterator = entries.iterator();
		while (iterator.hasNext()) {
			Entry<Integer, String> keyAndValue = iterator.next();
			System.out.println(keyAndValue.getKey() + " & " + keyAndValue.getValue());
		}
	}

}
