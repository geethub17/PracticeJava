package practice;

public final class FinalClass {

	final String panNumber;
	
	public FinalClass(String panNumber) {
		this.panNumber = panNumber;
	}
	
//	public void setPanNumber(String panNumber) {
//		this.panNumber = panNumber;
//	}
	
	public String getPanNumber() {
		return this.panNumber;
	}
	public static void main(String[] args) {
		FinalClass finalClass = new FinalClass("BNVPA5744E");
		System.out.println(finalClass.getPanNumber());
	}
}
