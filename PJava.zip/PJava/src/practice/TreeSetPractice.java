package practice;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetPractice {
	public static void main(String[] args) {
		TreeSet<String> treeSet = new TreeSet<String>();
		treeSet.add("Nandan10");
		treeSet.add("Nandan09");
		treeSet.add("Nandan05");
		treeSet.add("Nandan01");
		treeSet.add("Nandan01");
		treeSet.add("Nandan02");
		treeSet.add("Nandan03");
		treeSet.add("Nandan04");

		System.out.println(treeSet);

		Iterator<String> iterator = treeSet.iterator();
//		while (iterator.hasNext()) {
////			System.out.println(iterator.next());
//		}
		System.out.println(treeSet.headSet("Nandan03", false));
		System.out.println(treeSet);
		
	}
}
