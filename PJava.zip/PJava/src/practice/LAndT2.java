package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LAndT2 {

	public static void main(String[] args) {
		List<String> list = new ArrayList<String>(Arrays.asList("apple", "mango", "ball"));
		System.out.println(list.toString().replaceAll("[ \\[ \\] ]", "").replaceAll(",", ";"));
	}
}
