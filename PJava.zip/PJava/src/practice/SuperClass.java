package practice;

public class SuperClass {

	public void method1() {
		System.out.println("Method1 from super class.");
	}

	public  void method2() {
		System.out.println("Method2 from super class.");
	}
	
	public void method4() {
		System.out.println("Method4 from super class.");
	}
	
	public void method5() {
		System.out.println("Method5 from super class.");
	}

	public static void main(String[] args) {
		SuperClass superClass = new SuperClass();
		superClass.method1();
		superClass.method2();

		System.out.println("*********************************");
		
		SubClass subClass = new SubClass();
		subClass.method1();
		subClass.method2();
		
		System.out.println("*********************************");

		SuperClass sc = new SubClass();
		sc.method1();
		sc.method2();
		sc.method4();


	}
}
