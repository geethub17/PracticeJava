package practice;

public class ControlStatements {

	public enum Day {
		Sun, Mon, Tue, Wed, Thu, Fri, Sat

	}

	public static void switchExample() {
		int x = 5;

		switch (x) {
		case 1:
			System.out.println("Nandan1");
			break;

		case 2:
			System.out.println("Nandan2");
			break;

		default:
			System.out.println("I am default.");
			break;
		}
	}

	public static void forExample() {
		
		

		a: for (int i = 0; i < 3; i++) {
			b: for (int j = 0; j < 2; j++) {
				if (i == 1) {
					break a;
				}
				System.out.println(j);
			}
		}
	}

	public static void main(String[] args) {
		
		int x = 3;
		switch(x){
        default:
            System.out.println("Default");
        case 0:
            System.out.println("Case 0");
            break;
        case 1:
            System.out.println("Case 1");
        case 2:
            System.out.println("Case 2");
    }

	}
}
