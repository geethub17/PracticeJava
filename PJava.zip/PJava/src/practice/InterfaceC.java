package practice;

public interface InterfaceC {
	
	public void interfaceMthod1();

}
