package practice;

public class LAndT {

	public static boolean isArmstrong(int n) {

		int sum = 0;
		int temp = n;
		int len = String.valueOf(n).length();

		while (n != 0) {
			sum += Math.pow(n % 10, len);
			n = n / 10;
		}

		if (sum == temp) {
			System.out.println(temp + " is an armstrong number.");
			return true;
		}

		System.out.println(temp + " is not an armstrong number.");
		return false;
	}

	public static void main(String[] args) {
		isArmstrong(-1);
	}
}
