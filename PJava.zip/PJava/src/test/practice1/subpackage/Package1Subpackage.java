package test.practice1.subpackage;

public class Package1Subpackage {
	public void msg() {
		System.out.println("Hello, I am subpackage of package one.");
	}

}
