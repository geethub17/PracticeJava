package test.practice1;

public class Package1Class {

	public void msg() {
		System.out.println("Hello, I am package one.");
	}

}
