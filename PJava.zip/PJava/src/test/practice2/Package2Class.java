package test.practice2;

import test.practice1.Package1Class;

public class Package2Class {

	public static void main(String[] args) {
		Package1Class package1Class = new Package1Class();
		package1Class.msg();
		
		test.practice1.Package1Class package1Class2 = new test.practice1.Package1Class();
		package1Class2.msg();
	}
}
